#include "settings.h"
#include "ui_settings.h"

#include "qstring.h"

#include <QMouseEvent>
#include <QApplication>
#include <QGraphicsDropShadowEffect>
#include "control.h"
#include "qdebug.h"
#include "ctkRangeSlider.h"

settings::settings(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::settings)
{
    completeUi();
    connect(ui->pushButton_2, SIGNAL(clicked()), this, SLOT(showMinimized()));
    //connect(ui->pushButton_3, SIGNAL(clicked()), qApp, SLOT(quit()));

}

settings::~settings()
{
    delete ui;
}
void settings::completeUi()
{
    ui->setupUi(this);
    setWindowFlags(Qt::Window | Qt::FramelessWindowHint);

    m_selectedTabIndex = 0;
    m_tabButtons[0] = ui->pushButton_5;
    m_tabButtons[1] = ui->pushButton_6;
    m_tabButtons[2] = ui->pushButton_7;
    m_tabButtons[3] = ui->pushButton_8;
    m_tabButtons[4] = ui->pushButton_9;


    for (int i = 0; i < CREATE_ENTRY_DIALOG_TABS; i++)
    {
        connect(m_tabButtons[i], SIGNAL(clicked()), this, SLOT(onSelectedTab()));
    }

    ui->label_40->hide();
    ui->label_43->hide();
    ui->label_44->hide();
    ui->label_45->hide();
    slider();
}

void settings::onSelectedTab()
{
    QPushButton *button = (QPushButton *)sender();
    for (int i = 0; i < CREATE_ENTRY_DIALOG_TABS; i++)
    {
        bool checked = button == m_tabButtons[i];
        m_tabButtons[i]->setChecked(checked);
        if (checked)
        {
            ui->stackedWidget->setCurrentIndex(i);
        }
    }
}

void settings::slider()
{
//    SuperSlider * slider  = new SuperSlider(ui->slider_1);
//    //slider->setOrientation(Qt::Horizontal);
//    slider->setFixedWidth(300);
//   // SuperSliderHandle * otherhandler = new SuperSliderHandle(slider);

//    SuperSlider * slider2  = new SuperSlider(ui->slider_2);
//    SuperSliderHandle * sliderHandle2  = new SuperSliderHandle(slider2);
//    //sliderHandle2->setOpenExternalLinks(true);
//    slider2->setOrientation(Qt::Vertical);
//    slider2->setFixedHeight(300);
    //slider2->setFixedWidth(300);

    ctkRangeSlider *rangeSlider_horizental = new  ctkRangeSlider(Qt::Horizontal,ui->slider_1);
    rangeSlider_horizental->setGeometry(0,0,300,30);
    rangeSlider_horizental->setStyleSheet("QSlider::handle:horizontal { background-image:  url(:/images/settings/sliderbar2.png); margin-top: -10px;  margin-bottom: -12px;height: 32px;}");

    ctkRangeSlider *rangeSlider_vertical = new  ctkRangeSlider(Qt::Vertical,ui->slider_2);
    rangeSlider_vertical->setGeometry(0,0,30,250);

    ctkRangeSlider *rangeSlider_3 = new  ctkRangeSlider(Qt::Horizontal,ui->slider_3);
    rangeSlider_3->setGeometry(0,0,200,20);
    rangeSlider_3->setStyleSheet("QSlider::groove:horizontal {"
                                 "border: none;"
                                 "height: 4px; /* the groove expands to the size of the slider by default. by giving it a height, it has a fixed size */"
                                 "background: qlineargradient(x1:1, y1:1, x2:1, y2:1, stop:1 #B1B1B1, stop:1 #c4c4c4);"
                                 "margin: 2px 2;"
                             "}"
                             "QSlider::handle:horizontal {"
                                 "background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #53c1f2, stop:1 #53c1f2);"
                                 "border: none;"
                                 "width: 15px;"
                                 "height: 18px;"
                                 "bottom:-4px;"
                                 "right:-1px;"
                                 "left:3px;"
                                 "top:-5px;"
                                 "margin: -2px 3; /* handle is placed by default on the contents rect of the groove. Expand outside the groove */"
                                 "border-radius: 3px;}"

                                 );

    ctkRangeSlider *rangeSlider_4 = new  ctkRangeSlider(Qt::Horizontal,ui->slider_4);
    rangeSlider_4->setGeometry(0,0,200,20);

    rangeSlider_4->setStyleSheet("QSlider::groove:horizontal {"
                                 "border: none;"
                                 "height: 2px; /* the groove expands to the size of the slider by default. by giving it a height, it has a fixed size */"
                                 "background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #B1B1B1, stop:1 #c4c4c4);"
                                 "margin: 2px 0;"
                             "}"
                             "QSlider::handle:horizontal {"
                                 "background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #53c1f2, stop:1 #53c1f2);"
                                 "border: none;"
                                 "width: 15px;"
                                 "height: 18px;"
                                 "bottom:-4px;"
                                 "right:-1px;"
                                 "left:3px;"
                                 "top:-5px;"
                                 "margin: -2px 3; /* handle is placed by default on the contents rect of the groove. Expand outside the groove */"
                                 "border-radius: 3px;"
                             "}");
}
void settings::on_lineEdit_3_returnPressed()
{
    QString successStr = ui->lineEdit_3->text();
    if(!successStr.isEmpty())
    {
        ui->label_40->show();
        ui->label_44->show();
    }
    else{
        ui->label_40->hide();
        ui->label_44->hide();
    }
}

void settings::on_lineEdit_4_returnPressed()
{
    QString errorStr = ui->lineEdit_4->text();
    if(!errorStr.isEmpty())
    {
        ui->label_43->show();
        ui->label_45->show();
    }
    else{
        ui->label_43->hide();
        ui->label_45->hide();
    }
}

void settings::on_pushButton_3_clicked()
{
    close();
}
void settings::mouseMoveEvent(QMouseEvent *event)
{
    if (event->buttons() && Qt::LeftButton) {
        if (m_capturedMenuBar)
        {
            move(event->globalPos() - m_dragPosition);
        }
        else
        {
            QRect titleRect = ui->widget->frameGeometry();
            QPoint touchPos = event->globalPos() - frameGeometry().topLeft();
            if (titleRect.contains(touchPos))
            {
                m_capturedMenuBar = true;
                m_dragPosition = touchPos;
            }
        }
        event->accept();
    }
}

void settings::mousePressEvent(QMouseEvent *event)
{
    m_capturedMenuBar = false;
    if (event->button() == Qt::LeftButton) {
        QRect titleRect = ui->widget->frameGeometry();
        QPoint touchPos = event->globalPos() - frameGeometry().topLeft();
        if (titleRect.contains(touchPos))
        {
            m_capturedMenuBar = true;
            m_dragPosition = touchPos;
            event->accept();
        }
    }
}

void settings::mouseReleaseEvent(QMouseEvent *event)
{
    m_capturedMenuBar = false;
}
