#ifndef MACDIALOG_H
#define MACDIALOG_H

#include <QDialog>

class QLabel;
class MacDialog : public QDialog
{
public:
    MacDialog(QWidget *parent);

    void        setupTitleBar(QWidget *titleWidget, QLabel *titleLabel, bool dialogStyle = true);

    void        addShadowEffect();

protected:
    virtual
    void        mouseMoveEvent(QMouseEvent *event) override;
    virtual
    void        mousePressEvent(QMouseEvent *event) override;
    virtual
    void        mouseReleaseEvent(QMouseEvent *event)override;

private:
    QWidget *   m_titleBar;

    QPoint      m_dragPosition;
    bool        m_capturedMenuBar;
};

#endif // MACDIALOG_H
