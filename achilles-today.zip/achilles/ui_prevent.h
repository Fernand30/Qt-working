/********************************************************************************
** Form generated from reading UI file 'prevent.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PREVENT_H
#define UI_PREVENT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_prevent
{
public:
    QWidget *widget;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton;
    QTabWidget *tabWidget;
    QWidget *tab;
    QTableWidget *tableWidget;
    QWidget *tab_3;
    QWidget *tab_2;

    void setupUi(QDialog *prevent)
    {
        if (prevent->objectName().isEmpty())
            prevent->setObjectName(QStringLiteral("prevent"));
        prevent->resize(760, 582);
        prevent->setStyleSheet(QLatin1String("QDialog#prevent{\n"
"background-color: rgb(255, 255, 255);\n"
"}"));
        widget = new QWidget(prevent);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(0, 0, 760, 130));
        widget->setStyleSheet(QStringLiteral("background-image: url(:/images/update/header.png);"));
        pushButton_2 = new QPushButton(widget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(680, 0, 40, 40));
        pushButton_2->setStyleSheet(QStringLiteral("QPushButton{border-image:url(:/images/update/minibutton_normal.png);border:0px;} QPushButton:hover{border-image:url(:/images/update/minibutton_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/update/minibutton_on.png); position: relative;top: 1px; left: 1px;}"));
        pushButton_3 = new QPushButton(widget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(670, 40, 90, 90));
        pushButton_3->setStyleSheet(QLatin1String("QPushButton{\n"
"		border-image:url(:/images/back_normal.png);border:0px;\n"
"} \n"
"QPushButton:hover{\n"
"		border-image:url(:/images/back_over.png);border:0px;\n"
"} \n"
"QPushButton:pressed{\n"
"		border-image:url(:/images/back_on.png); position: relative;top: 1px; left: 1px;\n"
"}"));
        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(720, 0, 40, 40));
        pushButton->setStyleSheet(QStringLiteral("QPushButton{border-image:url(:/images/update/closebutton_normal.png);border:0px;} QPushButton:hover{border-image:url(:/images/update/closebutton_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/update/closebutton_on.png); position: relative;top: 1px; left: 1px;}"));
        tabWidget = new QTabWidget(prevent);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(10, 99, 740, 474));
        tabWidget->setStyleSheet(QLatin1String("/*QTabBar::tab {\n"
"    border-image: url(:/images/present/being_normal.png);\n"
"    min-width:156px; \n"
"    min-height:32px;\n"
"	font: 13pt \"MS Shell Dlg 2\";\n"
"	color: #ff8135;\n"
"	background-color:#ffffff;\n"
"	border-top-left-radius: 4px;\n"
"	border-top-right-radius: 4px;\n"
"	margin-left: 2px;\n"
" \n"
"}\n"
"\n"
"QTabBar::tab:press{\n"
"	font: 13pt \"MS Shell Dlg 2\";\n"
"    border-image: url(:/images/present/being_on.png); \n"
" 	min-width:156px;\n"
"    min-height:32px; \n"
"	color: #ffffff;\n"
"	background-color:#ffffff;\n"
"border:0;\n"
" \n"
"}\n"
"\n"
"QTabBar::tab:hover{\n"
"    border-image: url(:/images/present/being_over.png); \n"
" 	min-width:156px;\n"
"    min-height:32px;\n"
"	color: #ffcbac;\n"
"	background-color:#ffffff;\n"
"border:0;\n"
"  \n"
"}\n"
"QTabWidget::pane { border: 0; }*/\n"
"\n"
"QTabBar::tab {\n"
"    min-width:156px; \n"
"    min-height:32px;\n"
"	font: 13pt \"MS Shell Dlg 2\";\n"
"	color: #ff8135;\n"
"	background-color:#c55715;\n"
"	border-top-left-radius: 3px;\n"
""
                        "	border-top-right-radius: 3px;\n"
"	margin-left: 2px;\n"
"}\n"
"\n"
"\n"
"QTabBar::tab:hover{\n"
"    font: 13pt \"MS Shell Dlg 2\"; \n"
" 	min-width:156px;\n"
"    min-height:32px;\n"
"	color: #ffcbac;\n"
"	background-color:#e5712b;\n"
"border:0;\n"
"}\n"
"\n"
"QTabBar::tab:selected{\n"
"	font: 13pt \"MS Shell Dlg 2\";\n"
"   \n"
" 	min-width:156px;\n"
"    min-height:32px; \n"
"	color: #ffffff;\n"
"	background-color:#ff8135;\n"
"border:0;\n"
"}	\n"
"\n"
"/*QTabWidget::tab-bar  QWidget{\n"
"	border-radius: 0px;\n"
"    background-color:  rgba(255, 255, 255, 0);\n"
"}\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"QTabWidget::pane {\n"
"	/* margin: 0px,1px,1px,1px; \n"
"	border: 1px solid #020202;s\n"
"	border-radius: 4px;\n"
"      }\n"
"\n"
"\n"
"  QTabWidget::tab-bar {          \n"
"	left: 5px; /* move to the right by 5px \n"
"   bottom: 0px; \n"
"   background-color: red; /* nothing happens\n"
" } \n"
"\n"
"\n"
"\n"
"\n"
"QTabBar::tab { \n"
"\n"
"\n"
"	/*border-bottom-color: #C2C7CB; /* same as the pane color  \n"
"   backg"
                        "round: rgba(255, 255, 255, 0);\n"
"   padding: 3px;\n"
"   color:#FEFEFE;\n"
" }\n"
"       \n"
"QTabBar::tab:hover {\n"
"  background: rgba(255, 119, 0, 120);\n"
"	border-top-left-radius: 4px;\n"
"	border-top-right-radius: 4px;\n"
"}\n"
"\n"
"\n"
"QTabBar::tab:selected{\n"
"    background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,                                      stop: 0 #fafafa, stop: 0.4 #f4f4f4,                                      stop: 0.5 #e7e7e7, stop: 1.0 #fafafa); \n"
"\n"
"\n"
"	border-top-left-radius: 4px;\n"
"	border-top-right-radius: 4px;\n"
"   color:#2A2A2A;\n"
"}\n"
"*/"));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        tableWidget = new QTableWidget(tab);
        if (tableWidget->columnCount() < 4)
            tableWidget->setColumnCount(4);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        if (tableWidget->rowCount() < 3)
            tableWidget->setRowCount(3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(0, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(1, __qtablewidgetitem5);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(2, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        tableWidget->setItem(0, 0, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        tableWidget->setItem(0, 1, __qtablewidgetitem8);
        QTableWidgetItem *__qtablewidgetitem9 = new QTableWidgetItem();
        tableWidget->setItem(0, 2, __qtablewidgetitem9);
        QTableWidgetItem *__qtablewidgetitem10 = new QTableWidgetItem();
        tableWidget->setItem(0, 3, __qtablewidgetitem10);
        QTableWidgetItem *__qtablewidgetitem11 = new QTableWidgetItem();
        tableWidget->setItem(1, 0, __qtablewidgetitem11);
        QTableWidgetItem *__qtablewidgetitem12 = new QTableWidgetItem();
        tableWidget->setItem(1, 1, __qtablewidgetitem12);
        QTableWidgetItem *__qtablewidgetitem13 = new QTableWidgetItem();
        tableWidget->setItem(1, 2, __qtablewidgetitem13);
        QTableWidgetItem *__qtablewidgetitem14 = new QTableWidgetItem();
        tableWidget->setItem(1, 3, __qtablewidgetitem14);
        QTableWidgetItem *__qtablewidgetitem15 = new QTableWidgetItem();
        tableWidget->setItem(2, 0, __qtablewidgetitem15);
        QTableWidgetItem *__qtablewidgetitem16 = new QTableWidgetItem();
        tableWidget->setItem(2, 1, __qtablewidgetitem16);
        QTableWidgetItem *__qtablewidgetitem17 = new QTableWidgetItem();
        tableWidget->setItem(2, 2, __qtablewidgetitem17);
        QTableWidgetItem *__qtablewidgetitem18 = new QTableWidgetItem();
        tableWidget->setItem(2, 3, __qtablewidgetitem18);
        tableWidget->setObjectName(QStringLiteral("tableWidget"));
        tableWidget->setGeometry(QRect(-3, 8, 740, 436));
        tableWidget->setStyleSheet(QLatin1String("QHeaderView::section {\n"
"    background-color: #ffffff;\n"
"    font-size: 12pt;\n"
"	color:#8399a4;\n"
"	border:1px solid #fffff8; \n"
"}\n"
"\n"
"QHeaderView::section:horizontal\n"
"{\n"
"    border-color: #cfd8dc;\n"
"}\n"
"QHeaderView::section:vertical\n"
"{\n"
"   \n"
"}\n"
"QTableWidget{\n"
"	border:1px solid #cfd8dc;\n"
"	color:#84a0b4;\n"
"    font-size:11pt;\n"
"}\n"
"\n"
"/*QTableWidget{\n"
"	border:1px solid #8399a4;\n"
"	color:#84a0b4;\n"
"    font-size:11pt;\n"
"}\n"
"QHeaderView {\n"
"     color:#8399a4;\n"
" font-size: 14pt;\n"
"}\n"
"\n"
"QHeaderView::section:horizontal\n"
"{\n"
"     background-color: #ffffff;\n"
"    font-size: 12pt;\n"
"	color:#8399a4;\n"
"	border:1px solid #fffff8; \n"
"}*/\n"
"\n"
" QTableWidget{\n"
"         /*selection-background-color: qlineargradient(x1: 0, y1: 0, x2: 0.5, y2: 0.5,\n"
"                                     stop: 0 #FF92BB, stop: 1 white);*/\n"
"			selection-background-color:#bbdefb;\n"
"			selection-color:#84a0b4;\n"
"     }"));
        tableWidget->setAutoScroll(false);
        tableWidget->setAlternatingRowColors(true);
        tableWidget->setSelectionMode(QAbstractItemView::SingleSelection);
        tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
        tabWidget->addTab(tab, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        tabWidget->addTab(tab_3, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        tabWidget->addTab(tab_2, QString());

        retranslateUi(prevent);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(prevent);
    } // setupUi

    void retranslateUi(QDialog *prevent)
    {
        prevent->setWindowTitle(QApplication::translate("prevent", "Dialog", Q_NULLPTR));
        pushButton_2->setText(QString());
        pushButton_3->setText(QString());
        pushButton->setText(QString());
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("prevent", "Icons", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("prevent", "Name", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("prevent", "Path", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("prevent", "Details", Q_NULLPTR));

        const bool __sortingEnabled = tableWidget->isSortingEnabled();
        tableWidget->setSortingEnabled(false);
        QTableWidgetItem *___qtablewidgetitem4 = tableWidget->item(0, 0);
        ___qtablewidgetitem4->setText(QApplication::translate("prevent", "Icon1", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem5 = tableWidget->item(0, 1);
        ___qtablewidgetitem5->setText(QApplication::translate("prevent", "Game.exe", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem6 = tableWidget->item(0, 2);
        ___qtablewidgetitem6->setText(QApplication::translate("prevent", "C:/Program Files/Games", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem7 = tableWidget->item(0, 3);
        ___qtablewidgetitem7->setText(QApplication::translate("prevent", "Button1", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem8 = tableWidget->item(1, 0);
        ___qtablewidgetitem8->setText(QApplication::translate("prevent", "Icon2", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem9 = tableWidget->item(1, 1);
        ___qtablewidgetitem9->setText(QApplication::translate("prevent", "Updater.exe", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem10 = tableWidget->item(1, 2);
        ___qtablewidgetitem10->setText(QApplication::translate("prevent", "C:/Program Files/Shared Data", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem11 = tableWidget->item(1, 3);
        ___qtablewidgetitem11->setText(QApplication::translate("prevent", "Button1", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem12 = tableWidget->item(2, 0);
        ___qtablewidgetitem12->setText(QApplication::translate("prevent", "Icon3", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem13 = tableWidget->item(2, 1);
        ___qtablewidgetitem13->setText(QApplication::translate("prevent", "Updater.exe", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem14 = tableWidget->item(2, 2);
        ___qtablewidgetitem14->setText(QApplication::translate("prevent", "C:/Program Files/Shared Data", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem15 = tableWidget->item(2, 3);
        ___qtablewidgetitem15->setText(QApplication::translate("prevent", "Button1", Q_NULLPTR));
        tableWidget->setSortingEnabled(__sortingEnabled);

        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("prevent", "Being Watched", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("prevent", "Trudted", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("prevent", "Untrusted", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class prevent: public Ui_prevent {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PREVENT_H
