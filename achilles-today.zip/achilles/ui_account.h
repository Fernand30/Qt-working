/********************************************************************************
** Form generated from reading UI file 'account.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ACCOUNT_H
#define UI_ACCOUNT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Account
{
public:
    QWidget *widget;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QWidget *widget_2;
    QLabel *label;

    void setupUi(QDialog *Account)
    {
        if (Account->objectName().isEmpty())
            Account->setObjectName(QStringLiteral("Account"));
        Account->resize(760, 582);
        Account->setStyleSheet(QLatin1String("QDialog#Account{\n"
"background-color: rgb(255, 255, 255);\n"
"}"));
        widget = new QWidget(Account);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(0, 0, 760, 130));
        widget->setStyleSheet(QStringLiteral("background-image: url(:/images/account/header.png);"));
        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(680, 0, 40, 40));
        pushButton->setStyleSheet(QStringLiteral("QPushButton{border-image:url(:/images/account/minibutton_normal.png);border:0px;} QPushButton:hover{border-image:url(:/images/account/minibutton_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/account/minibutton_on.png); position: relative;top: 1px; left: 1px;}"));
        pushButton_2 = new QPushButton(widget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(720, 0, 40, 40));
        pushButton_2->setStyleSheet(QStringLiteral("QPushButton{border-image:url(:/images/account/closebutton_normal.png);border:0px;} QPushButton:hover{border-image:url(:/images/account/closebutton_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/account/closebutton_on.png); position: relative;top: 1px; left: 1px;}"));
        pushButton_3 = new QPushButton(widget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(670, 40, 90, 90));
        pushButton_3->setStyleSheet(QLatin1String("QPushButton{\n"
"		border-image:url(:/images/back_normal.png);border:0px;\n"
"} \n"
"QPushButton:hover{\n"
"		border-image:url(:/images/back_over.png);border:0px;\n"
"} \n"
"QPushButton:pressed{\n"
"		border-image:url(:/images/back_on.png); position: relative;top: 1px; left: 1px;\n"
"}"));
        pushButton_4 = new QPushButton(widget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(10, 98, 100, 32));
        QFont font;
        font.setFamily(QStringLiteral("MS Shell Dlg 2"));
        font.setPointSize(14);
        font.setBold(false);
        font.setItalic(false);
        font.setWeight(50);
        pushButton_4->setFont(font);
        pushButton_4->setStyleSheet(QLatin1String("QPushButton{\n"
"		border-image:url(:/images/account/account_button.png);border:0px; color:#ffffff;font: 14pt \"MS Shell Dlg 2\";\n"
"		border-top-left-radius: 3px;\n"
"		border-top-right-radius: 3px;\n"
"} "));
        pushButton_4->setFlat(true);
        widget_2 = new QWidget(Account);
        widget_2->setObjectName(QStringLiteral("widget_2"));
        widget_2->setGeometry(QRect(10, 140, 742, 432));
        widget_2->setStyleSheet(QStringLiteral("background-image: url(:/images/account/background.png);"));
        label = new QLabel(widget_2);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(100, 50, 500, 53));
        label->setStyleSheet(QLatin1String("background-image: url(:/images/account/text.png);\n"
"background-color: rgb(246, 246, 246);"));

        retranslateUi(Account);

        QMetaObject::connectSlotsByName(Account);
    } // setupUi

    void retranslateUi(QDialog *Account)
    {
        Account->setWindowTitle(QApplication::translate("Account", "Dialog", Q_NULLPTR));
        pushButton->setText(QString());
        pushButton_2->setText(QString());
        pushButton_3->setText(QString());
        pushButton_4->setText(QApplication::translate("Account", "Account", Q_NULLPTR));
        label->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Account: public Ui_Account {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ACCOUNT_H
