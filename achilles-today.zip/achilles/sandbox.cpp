#include "sandbox.h"
#include "ui_sandbox.h"

sandbox::sandbox(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::sandbox)
{
    completeUi();
    autoWidth();
}

sandbox::~sandbox()
{
    delete ui;
}
void sandbox::autoWidth()
{
        ui->tableWidget_2->verticalHeader()->hide();
        ui->tableWidget_2->setColumnWidth(0,100);
        ui->tableWidget_2->setColumnWidth(1,150);
        ui->tableWidget_2->setColumnWidth(2,300);
        ui->tableWidget_2->setColumnWidth(3,180);
}
void sandbox::completeUi()
{
    ui->setupUi(this);
    setWindowFlags(Qt::Window | Qt::FramelessWindowHint);
}
