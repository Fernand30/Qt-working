#ifndef MAINMENU_H
#define MAINMENU_H

#include <QDialog>

#include "firewall.h"
#include "account.h"
#include "exploit.h"
#include "prevent.h"
#include "sand.h"
#include "settings.h"
#include "updatedialog.h"

namespace Ui {
class mainmenu;
}

class mainmenu : public QDialog
{
    Q_OBJECT

public:
    explicit mainmenu(QWidget *parent = 0);
    ~mainmenu();
protected:
    void    mouseMoveEvent(QMouseEvent *event);
    void    mousePressEvent(QMouseEvent *event);
    void    mouseReleaseEvent(QMouseEvent *event);
private:
    QPoint          m_dragPosition;
    bool            m_capturedMenuBar;
private:
    void    completeUi();
    Ui::mainmenu *ui;

private slots:
    void prevente();
    void fire();
    void exp();
    void sandbox();
    void updateDlg();
    void sett();
    void acc();
    void on_pushButton_7_clicked();
    void on_pushButton_3_clicked();
};

#endif // MAINMENU_H
