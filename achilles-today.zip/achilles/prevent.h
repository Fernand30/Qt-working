#ifndef PREVENT_H
#define PREVENT_H

#include <QDialog>

namespace Ui {
class prevent;
}

class prevent : public QDialog
{
    Q_OBJECT

public:
    explicit prevent(QWidget *parent = 0);
    ~prevent();

protected:
    void    mouseMoveEvent(QMouseEvent *event);
    void    mousePressEvent(QMouseEvent *event);
    void    mouseReleaseEvent(QMouseEvent *event);
private:
    QPoint          m_dragPosition;
    bool            m_capturedMenuBar;


private slots:
    void on_pushButton_clicked();

private:
    Ui::prevent *ui;
    void autoWidth();
    void completeUi();
};

#endif // PREVENT_H
