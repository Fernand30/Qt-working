/********************************************************************************
** Form generated from reading UI file 'mainmenu.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINMENU_H
#define UI_MAINMENU_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_mainmenu
{
public:
    QWidget *widget;
    QWidget *widget_2;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;
    QPushButton *pushButton_8;
    QPushButton *pushButton_9;
    QPushButton *pushButton_10;

    void setupUi(QDialog *mainmenu)
    {
        if (mainmenu->objectName().isEmpty())
            mainmenu->setObjectName(QStringLiteral("mainmenu"));
        mainmenu->resize(760, 581);
        mainmenu->setWindowOpacity(100);
        mainmenu->setAutoFillBackground(true);
        mainmenu->setModal(false);
        widget = new QWidget(mainmenu);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(0, 0, 760, 581));
        widget->setStyleSheet(QStringLiteral(""));
        widget_2 = new QWidget(widget);
        widget_2->setObjectName(QStringLiteral("widget_2"));
        widget_2->setGeometry(QRect(0, 0, 760, 200));
        widget_2->setStyleSheet(QStringLiteral("background-image: url(:/images/mainmenu/completeHeader.png);"));
        pushButton = new QPushButton(widget_2);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(127, 91, 61, 45));
        pushButton->setStyleSheet(QStringLiteral("QPushButton{border-image:url(:/images/mainmenu/checkaffect.png);border:0px;} QPushButton:hover{border-image:url(:/images/mainmenu/checkaffect.png);border:0px} QPushButton:pressed{border-image:url(:/images/mainmenu/checkaffect.png); position: relative;top: 1px; left: 1px;}"));
        pushButton_2 = new QPushButton(widget_2);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(680, 0, 40, 40));
        pushButton_2->setStyleSheet(QStringLiteral("QPushButton{border-image:url(:/images/mainmenu/minibutton_normal.png);border:0px;} QPushButton:hover{border-image:url(:/images/mainmenu/minibutton_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/mainmenu/minibutton_on.png); position: relative;top: 1px; left: 1px;}"));
        pushButton_3 = new QPushButton(widget_2);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(720, 0, 40, 40));
        pushButton_3->setStyleSheet(QStringLiteral("QPushButton{border-image:url(:/images/mainmenu/closebutton_normal.png);border:0px;} QPushButton:hover{border-image:url(:/images/mainmenu/closebutton_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/mainmenu/closebutton_on.png); position: relative;top: 1px; left: 1px;}"));
        pushButton_4 = new QPushButton(widget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(2, 206, 263, 195));
        pushButton_4->setStyleSheet(QLatin1String("QPushButton{border-image:url(:/images/mainmenu/prevention_normal.png);border:0px;}\n"
"QPushButton:hover{border-image:url(:/images/mainmenu/prevention_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/mainmenu/prevention_on.png); position: relative;top: 1px; left: 1px;}"));
        pushButton_5 = new QPushButton(widget);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(2, 387, 263, 195));
        pushButton_5->setStyleSheet(QLatin1String("QPushButton{border-image:url(:/images/mainmenu/firewall_normal.png);border:0px;}\n"
"QPushButton:hover{border-image:url(:/images/mainmenu/firewall_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/mainmenu/firewall_on.png); position: relative;top: 1px; left: 1px;}"));
        pushButton_6 = new QPushButton(widget);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setGeometry(QRect(251, 206, 263, 195));
        pushButton_6->setStyleSheet(QLatin1String("QPushButton{border-image:url(:/images/mainmenu/exploit_normal.png);border:0px;}\n"
"QPushButton:hover{border-image:url(:/images/mainmenu/exploit_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/mainmenu/exploit_on.png); position: relative;top: 1px; left: 1px;}"));
        pushButton_7 = new QPushButton(widget);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        pushButton_7->setGeometry(QRect(251, 387, 263, 195));
        pushButton_7->setStyleSheet(QLatin1String("QPushButton{border-image:url(:/images/mainmenu/sandbox_normal.png);border:0px;}\n"
"QPushButton:hover{border-image:url(:/images/mainmenu/sandbox_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/mainmenu/sandbox_on.png); position: relative;top: 1px; left: 1px;}"));
        pushButton_8 = new QPushButton(widget);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));
        pushButton_8->setGeometry(QRect(500, 206, 258, 134));
        pushButton_8->setStyleSheet(QLatin1String("QPushButton{border-image:url(:/images/mainmenu/update_normal.png);border:0px;}\n"
"QPushButton:hover{border-image:url(:/images/mainmenu/update_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/mainmenu/update_on.png); position: relative;top: 1px; left: 1px;}"));
        pushButton_9 = new QPushButton(widget);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));
        pushButton_9->setGeometry(QRect(500, 326, 258, 134));
        pushButton_9->setStyleSheet(QLatin1String("QPushButton{border-image:url(:/images/mainmenu/settings_normal.png);border:0px;}\n"
"QPushButton:hover{border-image:url(:/images/mainmenu/settings_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/mainmenu/settings_on.png); position: relative;top: 1px; left: 1px;}"));
        pushButton_10 = new QPushButton(widget);
        pushButton_10->setObjectName(QStringLiteral("pushButton_10"));
        pushButton_10->setGeometry(QRect(500, 447, 258, 134));
        pushButton_10->setStyleSheet(QLatin1String("QPushButton{border-image:url(:/images/mainmenu/account_normal.png);border:0px;}\n"
"QPushButton:hover{border-image:url(:/images/mainmenu/account_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/mainmenu/account_on.png); position: relative;top: 1px; left: 1px;}"));

        retranslateUi(mainmenu);

        QMetaObject::connectSlotsByName(mainmenu);
    } // setupUi

    void retranslateUi(QDialog *mainmenu)
    {
        mainmenu->setWindowTitle(QApplication::translate("mainmenu", "Dialog", Q_NULLPTR));
        pushButton->setText(QString());
        pushButton_2->setText(QString());
        pushButton_3->setText(QString());
        pushButton_4->setText(QString());
        pushButton_5->setText(QString());
        pushButton_6->setText(QString());
        pushButton_7->setText(QString());
        pushButton_8->setText(QString());
        pushButton_9->setText(QString());
        pushButton_10->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class mainmenu: public Ui_mainmenu {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINMENU_H
