#ifndef SETTINGS_H
#define SETTINGS_H

#include <QDialog>
#include "SuperSlider.h"

namespace Ui {
class settings;
}
#define CREATE_ENTRY_DIALOG_TABS    5

class settings : public QDialog
{
    Q_OBJECT

public:
    explicit settings(QWidget *parent = 0);
    ~settings();

protected:
    void    mouseMoveEvent(QMouseEvent *event);
    void    mousePressEvent(QMouseEvent *event);
    void    mouseReleaseEvent(QMouseEvent *event);
private:
    QPoint          m_dragPosition;
    bool            m_capturedMenuBar;

private slots:
    void  onSelectedTab();

    void on_lineEdit_3_returnPressed();

    void on_lineEdit_4_returnPressed();

    void on_pushButton_3_clicked();

private:
    Ui::settings *ui;
    void completeUi();
    void slider();
    int                     m_selectedTabIndex;
    QPushButton *           m_tabButtons[CREATE_ENTRY_DIALOG_TABS];
};

#endif // SETTINGS_H
