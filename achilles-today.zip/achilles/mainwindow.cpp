#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "qtimer.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    completeUI();
    QTimer *t = new QTimer();
    connect( t, SIGNAL(timeout()), SLOT(quit()) );
    t->start(1000);
}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::completeUI()
{
    ui->setupUi(this);
    setWindowFlags(Qt::Window | Qt::FramelessWindowHint);

    //setWindowIcon(QIcon(":/images/icon.png"));
}

void MainWindow::quit()
{
     this->quit();
    //setWindowIcon(QIcon(":/images/icon.png"));
}
