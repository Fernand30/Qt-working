/********************************************************************************
** Form generated from reading UI file 'updatedialog.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_UPDATEDIALOG_H
#define UI_UPDATEDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_updateDialog
{
public:
    QWidget *widget;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QWidget *widget_3;
    QWidget *widget_2;
    QLabel *label;
    QPushButton *pushButton_5;

    void setupUi(QDialog *updateDialog)
    {
        if (updateDialog->objectName().isEmpty())
            updateDialog->setObjectName(QStringLiteral("updateDialog"));
        updateDialog->resize(760, 582);
        updateDialog->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));
        widget = new QWidget(updateDialog);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(0, 0, 760, 130));
        widget->setStyleSheet(QStringLiteral("background-image: url(:/images/update/header.png);"));
        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(720, 0, 40, 40));
        pushButton->setStyleSheet(QStringLiteral("QPushButton{border-image:url(:/images/update/closebutton_normal.png);border:0px;} QPushButton:hover{border-image:url(:/images/update/closebutton_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/update/closebutton_on.png); position: relative;top: 1px; left: 1px;}"));
        pushButton_2 = new QPushButton(widget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(680, 0, 40, 40));
        pushButton_2->setStyleSheet(QStringLiteral("QPushButton{border-image:url(:/images/update/minibutton_normal.png);border:0px;} QPushButton:hover{border-image:url(:/images/update/minibutton_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/update/minibutton_on.png); position: relative;top: 1px; left: 1px;}"));
        pushButton_3 = new QPushButton(widget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(670, 40, 90, 90));
        pushButton_3->setStyleSheet(QLatin1String("QPushButton{\n"
"		border-image:url(:/images/back_normal.png);border:0px;\n"
"} \n"
"QPushButton:hover{\n"
"		border-image:url(:/images/back_over.png);border:0px;\n"
"} \n"
"QPushButton:pressed{\n"
"		border-image:url(:/images/back_on.png); position: relative;top: 1px; left: 1px;\n"
"}"));
        pushButton_4 = new QPushButton(widget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(10, 98, 95, 32));
        pushButton_4->setStyleSheet(QLatin1String("QPushButton{\n"
"		border-image:url(:/images/update/update_button.png);\n"
"		color:#ffffff;\n"
"		font: 14pt \"MS Shell Dlg 2\";\n"
"		border-top-left-radius: 3px;\n"
"		border-top-right-radius: 3px;\n"
"} \n"
""));
        pushButton_4->setFlat(true);
        widget_3 = new QWidget(updateDialog);
        widget_3->setObjectName(QStringLiteral("widget_3"));
        widget_3->setGeometry(QRect(10, 140, 740, 432));
        widget_3->setStyleSheet(QLatin1String("QWidget#widget_3{\n"
"		background-color: rgb(255, 255, 255);\n"
"}"));
        widget_2 = new QWidget(widget_3);
        widget_2->setObjectName(QStringLiteral("widget_2"));
        widget_2->setGeometry(QRect(0, 0, 740, 432));
        widget_2->setStyleSheet(QStringLiteral("background-color:#f6f6f6;"));
        label = new QLabel(widget_2);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(30, 30, 299, 53));
        label->setStyleSheet(QStringLiteral("background-image: url(:/images/update/text.png);"));
        pushButton_5 = new QPushButton(widget_2);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(448, 17, 286, 77));
        pushButton_5->setStyleSheet(QLatin1String("\n"
"QPushButton{\n"
"		border-image:url(:/images/update/update_normal.png);\n"
"		border: 3px;\n"
"}\n"
"QPushButton:hover{\n"
"		border-image:url(:/images/update/update_over.png);\n"
"		border: 3px;\n"
"} \n"
"QPushButton:pressed{\n"
"		border-image:url(:/images/update/update_on.png); position: relative;top: 1px; left: 1px;\n"
"		border: 3px;\n"
"}"));
        pushButton_5->setAutoRepeat(false);
        pushButton_5->setAutoDefault(false);
        pushButton_5->setFlat(false);

        retranslateUi(updateDialog);

        QMetaObject::connectSlotsByName(updateDialog);
    } // setupUi

    void retranslateUi(QDialog *updateDialog)
    {
        updateDialog->setWindowTitle(QApplication::translate("updateDialog", "Dialog", Q_NULLPTR));
        pushButton->setText(QString());
        pushButton_2->setText(QString());
        pushButton_3->setText(QString());
        pushButton_4->setText(QApplication::translate("updateDialog", "Update", Q_NULLPTR));
        label->setText(QString());
        pushButton_5->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class updateDialog: public Ui_updateDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_UPDATEDIALOG_H
