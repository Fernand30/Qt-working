/********************************************************************************
** Form generated from reading UI file 'firewall.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FIREWALL_H
#define UI_FIREWALL_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Firewall
{
public:
    QWidget *widget;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton;
    QPushButton *pushButton_4;
    QTableWidget *tableWidget;

    void setupUi(QDialog *Firewall)
    {
        if (Firewall->objectName().isEmpty())
            Firewall->setObjectName(QStringLiteral("Firewall"));
        Firewall->resize(760, 582);
        Firewall->setStyleSheet(QLatin1String("QDialog#Firewall\n"
"{\n"
"		background-color: rgb(255, 255, 255);\n"
"}"));
        Firewall->setModal(false);
        widget = new QWidget(Firewall);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(0, 0, 760, 130));
        widget->setStyleSheet(QStringLiteral("background-image: url(:/images/update/header.png);"));
        pushButton_2 = new QPushButton(widget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(680, 0, 40, 40));
        pushButton_2->setStyleSheet(QStringLiteral("QPushButton{border-image:url(:/images/update/minibutton_normal.png);border:0px;} QPushButton:hover{border-image:url(:/images/update/minibutton_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/update/minibutton_on.png); position: relative;top: 1px; left: 1px;}"));
        pushButton_3 = new QPushButton(widget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(670, 40, 90, 90));
        pushButton_3->setStyleSheet(QLatin1String("QPushButton{\n"
"		border-image:url(:/images/back_normal.png);border:0px;\n"
"} \n"
"QPushButton:hover{\n"
"		border-image:url(:/images/back_over.png);border:0px;\n"
"} \n"
"QPushButton:pressed{\n"
"		border-image:url(:/images/back_on.png); position: relative;top: 1px; left: 1px;\n"
"}"));
        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(720, 0, 40, 40));
        pushButton->setStyleSheet(QStringLiteral("QPushButton{border-image:url(:/images/update/closebutton_normal.png);border:0px;} QPushButton:hover{border-image:url(:/images/update/closebutton_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/update/closebutton_on.png); position: relative;top: 1px; left: 1px;}"));
        pushButton_4 = new QPushButton(Firewall);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(10, 98, 120, 32));
        pushButton_4->setStyleSheet(QLatin1String("QPushButton{\n"
"		border-image:url(:/images/firewall/firewall_button.png);\n"
"		 color:#ffffff;\n"
"		font: 14pt \"MS Shell Dlg 2\";\n"
"		border-top-left-radius: 3px;\n"
"		border-top-right-radius: 3px\n"
"}"));
        pushButton_4->setFlat(true);
        tableWidget = new QTableWidget(Firewall);
        if (tableWidget->columnCount() < 5)
            tableWidget->setColumnCount(5);
        QFont font;
        font.setPointSize(12);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        __qtablewidgetitem->setFont(font);
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        if (tableWidget->rowCount() < 7)
            tableWidget->setRowCount(7);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(0, __qtablewidgetitem5);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(1, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(2, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(3, __qtablewidgetitem8);
        QTableWidgetItem *__qtablewidgetitem9 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(4, __qtablewidgetitem9);
        QTableWidgetItem *__qtablewidgetitem10 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(5, __qtablewidgetitem10);
        QTableWidgetItem *__qtablewidgetitem11 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(6, __qtablewidgetitem11);
        QIcon icon;
        icon.addFile(QStringLiteral(":/images/firewall.png"), QSize(), QIcon::Normal, QIcon::Off);
        QTableWidgetItem *__qtablewidgetitem12 = new QTableWidgetItem();
        __qtablewidgetitem12->setFont(font);
        __qtablewidgetitem12->setIcon(icon);
        tableWidget->setItem(0, 0, __qtablewidgetitem12);
        QTableWidgetItem *__qtablewidgetitem13 = new QTableWidgetItem();
        tableWidget->setItem(0, 1, __qtablewidgetitem13);
        QTableWidgetItem *__qtablewidgetitem14 = new QTableWidgetItem();
        tableWidget->setItem(0, 2, __qtablewidgetitem14);
        QTableWidgetItem *__qtablewidgetitem15 = new QTableWidgetItem();
        tableWidget->setItem(0, 3, __qtablewidgetitem15);
        QTableWidgetItem *__qtablewidgetitem16 = new QTableWidgetItem();
        tableWidget->setItem(0, 4, __qtablewidgetitem16);
        QTableWidgetItem *__qtablewidgetitem17 = new QTableWidgetItem();
        __qtablewidgetitem17->setIcon(icon);
        tableWidget->setItem(1, 0, __qtablewidgetitem17);
        QTableWidgetItem *__qtablewidgetitem18 = new QTableWidgetItem();
        tableWidget->setItem(1, 1, __qtablewidgetitem18);
        QTableWidgetItem *__qtablewidgetitem19 = new QTableWidgetItem();
        tableWidget->setItem(1, 2, __qtablewidgetitem19);
        QTableWidgetItem *__qtablewidgetitem20 = new QTableWidgetItem();
        tableWidget->setItem(1, 3, __qtablewidgetitem20);
        QTableWidgetItem *__qtablewidgetitem21 = new QTableWidgetItem();
        tableWidget->setItem(1, 4, __qtablewidgetitem21);
        QTableWidgetItem *__qtablewidgetitem22 = new QTableWidgetItem();
        __qtablewidgetitem22->setIcon(icon);
        tableWidget->setItem(2, 0, __qtablewidgetitem22);
        QTableWidgetItem *__qtablewidgetitem23 = new QTableWidgetItem();
        tableWidget->setItem(2, 1, __qtablewidgetitem23);
        QTableWidgetItem *__qtablewidgetitem24 = new QTableWidgetItem();
        tableWidget->setItem(2, 2, __qtablewidgetitem24);
        QTableWidgetItem *__qtablewidgetitem25 = new QTableWidgetItem();
        tableWidget->setItem(2, 3, __qtablewidgetitem25);
        QTableWidgetItem *__qtablewidgetitem26 = new QTableWidgetItem();
        tableWidget->setItem(2, 4, __qtablewidgetitem26);
        tableWidget->setObjectName(QStringLiteral("tableWidget"));
        tableWidget->setEnabled(true);
        tableWidget->setGeometry(QRect(10, 140, 740, 431));
        tableWidget->setStyleSheet(QLatin1String("QHeaderView::section {\n"
"    background-color: #ffffff;\n"
"    font-size: 14pt;\n"
"	color:#8399a4;\n"
"	border:1px solid #fffff8; \n"
"}\n"
"\n"
"QHeaderView::section:horizontal\n"
"{\n"
"    border-color: #cfd8dc;\n"
"}\n"
"QHeaderView::section:vertical\n"
"{\n"
"   \n"
"}\n"
"QTableWidget{\n"
"	border:1px solid #cfd8dc;\n"
"	color:#84a0b4;\n"
"    font-size:11pt;\n"
"}\n"
"\n"
"/*QTableWidget{\n"
"	border:1px solid #8399a4;\n"
"	color:#84a0b4;\n"
"    font-size:11pt;\n"
"}\n"
"QHeaderView {\n"
"     color:#8399a4;\n"
" font-size: 14pt;\n"
"}\n"
"\n"
"QHeaderView::section:horizontal\n"
"{\n"
"     background-color: #ffffff;\n"
"    font-size: 12pt;\n"
"	color:#8399a4;\n"
"	border:1px solid #fffff8; \n"
"}*/\n"
"\n"
" QTableWidget{\n"
"         /*selection-background-color: qlineargradient(x1: 0, y1: 0, x2: 0.5, y2: 0.5,\n"
"                                     stop: 0 #FF92BB, stop: 1 white);*/\n"
"			selection-background-color:#bbdefb;\n"
"			selection-color:#84a0b4;\n"
"     }"));
        tableWidget->setAutoScroll(false);
        tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
        tableWidget->setAlternatingRowColors(true);
        tableWidget->setSelectionMode(QAbstractItemView::SingleSelection);
        tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);

        retranslateUi(Firewall);

        QMetaObject::connectSlotsByName(Firewall);
    } // setupUi

    void retranslateUi(QDialog *Firewall)
    {
        Firewall->setWindowTitle(QApplication::translate("Firewall", "Dialog", Q_NULLPTR));
        pushButton_2->setText(QString());
        pushButton_3->setText(QString());
        pushButton->setText(QString());
        pushButton_4->setText(QApplication::translate("Firewall", "Activities", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("Firewall", "Icon", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("Firewall", "Name", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("Firewall", "Path", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("Firewall", "Action", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem4 = tableWidget->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QApplication::translate("Firewall", "Details", Q_NULLPTR));

        const bool __sortingEnabled = tableWidget->isSortingEnabled();
        tableWidget->setSortingEnabled(false);
        QTableWidgetItem *___qtablewidgetitem5 = tableWidget->item(0, 1);
        ___qtablewidgetitem5->setText(QApplication::translate("Firewall", "Game.exe", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem6 = tableWidget->item(0, 2);
        ___qtablewidgetitem6->setText(QApplication::translate("Firewall", "C:/Program Files/Game", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem7 = tableWidget->item(0, 3);
        ___qtablewidgetitem7->setText(QApplication::translate("Firewall", "Listen", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem8 = tableWidget->item(0, 4);
        ___qtablewidgetitem8->setText(QApplication::translate("Firewall", "On Port 21", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem9 = tableWidget->item(1, 1);
        ___qtablewidgetitem9->setText(QApplication::translate("Firewall", "Update.exe", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem10 = tableWidget->item(1, 2);
        ___qtablewidgetitem10->setText(QApplication::translate("Firewall", "C:/Program Files/Shared Data", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem11 = tableWidget->item(1, 3);
        ___qtablewidgetitem11->setText(QApplication::translate("Firewall", "Connection", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem12 = tableWidget->item(1, 4);
        ___qtablewidgetitem12->setText(QApplication::translate("Firewall", "To http://www.google.com", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem13 = tableWidget->item(2, 1);
        ___qtablewidgetitem13->setText(QApplication::translate("Firewall", "Update.exe", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem14 = tableWidget->item(2, 2);
        ___qtablewidgetitem14->setText(QApplication::translate("Firewall", "C:/Program Files/Shared Data", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem15 = tableWidget->item(2, 3);
        ___qtablewidgetitem15->setText(QApplication::translate("Firewall", "Connection", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem16 = tableWidget->item(2, 4);
        ___qtablewidgetitem16->setText(QApplication::translate("Firewall", "To 192.168.0.138:30212", Q_NULLPTR));
        tableWidget->setSortingEnabled(__sortingEnabled);

    } // retranslateUi

};

namespace Ui {
    class Firewall: public Ui_Firewall {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FIREWALL_H
