#include "firewall.h"
#include "ui_firewall.h"

#include <QMouseEvent>
#include <QApplication>
#include <QGraphicsDropShadowEffect>
#include "qdebug.h"

Firewall::Firewall(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Firewall)
{
    completeUi();
    autoWidth();
}

Firewall::~Firewall()
{
    delete ui;
}
void Firewall::autoWidth()
{
        ui->tableWidget->verticalHeader()->hide();
        ui->tableWidget->setColumnWidth(0,100);
        ui->tableWidget->setColumnWidth(1,150);
        ui->tableWidget->setColumnWidth(2,210);
        ui->tableWidget->setColumnWidth(3,100);
        ui->tableWidget->setColumnWidth(4,180);
        ui->tableWidget->horizontalHeader()->setStretchLastSection(true);
        ui->tableWidget->setSelectionMode(QAbstractItemView::SingleSelection);
        ui->tableWidget->selectRow(0);
        QTableWidgetItem * protoitem = new QTableWidgetItem();
         protoitem->setTextAlignment(Qt::AlignRight);
        ui->tableWidget->setItemPrototype(protoitem);
}
void Firewall::completeUi()
{
    ui->setupUi(this);
    setWindowFlags(Qt::Window | Qt::FramelessWindowHint);
    connect(ui->pushButton_2, SIGNAL(clicked()), this, SLOT(showMinimized()));
    //connect(ui->pushButton, SIGNAL(clicked()), qApp, SLOT(quit()));
}

void Firewall::on_pushButton_clicked()
{
    close();
}
void Firewall::mouseMoveEvent(QMouseEvent *event)
{
    if (event->buttons() && Qt::LeftButton) {
        if (m_capturedMenuBar)
        {
            move(event->globalPos() - m_dragPosition);
        }
        else
        {
            QRect titleRect = ui->widget->frameGeometry();
            QPoint touchPos = event->globalPos() - frameGeometry().topLeft();
            if (titleRect.contains(touchPos))
            {
                m_capturedMenuBar = true;
                m_dragPosition = touchPos;
            }
        }
        event->accept();
    }
}

void Firewall::mousePressEvent(QMouseEvent *event)
{
    m_capturedMenuBar = false;
    if (event->button() == Qt::LeftButton) {
        QRect titleRect = ui->widget->frameGeometry();
        QPoint touchPos = event->globalPos() - frameGeometry().topLeft();
        if (titleRect.contains(touchPos))
        {
            m_capturedMenuBar = true;
            m_dragPosition = touchPos;
            event->accept();
        }
    }
}

void Firewall::mouseReleaseEvent(QMouseEvent *event)
{
    m_capturedMenuBar = false;
}
