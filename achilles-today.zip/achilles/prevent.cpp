#include "prevent.h"
#include "ui_prevent.h"

#include <QMouseEvent>
#include <QApplication>
#include <QGraphicsDropShadowEffect>
#include "qdebug.h"

prevent::prevent(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::prevent)
{
    completeUi();
}

prevent::~prevent()
{
    delete ui;
}
void prevent::autoWidth()
{
        ui->tableWidget->verticalHeader()->hide();
        ui->tableWidget->setColumnWidth(0,100);
        ui->tableWidget->setColumnWidth(1,160);
        ui->tableWidget->setColumnWidth(2,300);
        ui->tableWidget->setColumnWidth(3,179);
        ui->tableWidget->horizontalHeader()->setStretchLastSection(true);
        ui->tableWidget->setSelectionMode(QAbstractItemView::SingleSelection);
        ui->tableWidget->selectRow(0);
}
void prevent::completeUi()
{
    ui->setupUi(this);
    autoWidth();
    setWindowFlags(Qt::Window | Qt::FramelessWindowHint);
    connect(ui->pushButton_2, SIGNAL(clicked()), this, SLOT(showMinimized()));
    //connect(ui->pushButton, SIGNAL(clicked()), qApp, SLOT(quit()));
}

void prevent::on_pushButton_clicked()
{
    close();
}
void prevent::mouseMoveEvent(QMouseEvent *event)
{
    if (event->buttons() && Qt::LeftButton) {
        if (m_capturedMenuBar)
        {
            move(event->globalPos() - m_dragPosition);
        }
        else
        {
            QRect titleRect = ui->widget->frameGeometry();
            QPoint touchPos = event->globalPos() - frameGeometry().topLeft();
            if (titleRect.contains(touchPos))
            {
                m_capturedMenuBar = true;
                m_dragPosition = touchPos;
            }
        }
        event->accept();
    }
}

void prevent::mousePressEvent(QMouseEvent *event)
{
    m_capturedMenuBar = false;
    if (event->button() == Qt::LeftButton) {
        QRect titleRect = ui->widget->frameGeometry();
        QPoint touchPos = event->globalPos() - frameGeometry().topLeft();
        if (titleRect.contains(touchPos))
        {
            m_capturedMenuBar = true;
            m_dragPosition = touchPos;
            event->accept();
        }
    }
}

void prevent::mouseReleaseEvent(QMouseEvent *event)
{
    m_capturedMenuBar = false;
}
