/********************************************************************************
** Form generated from reading UI file 'settings.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SETTINGS_H
#define UI_SETTINGS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_settings
{
public:
    QWidget *widget;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QWidget *widget_6;
    QSlider *verticalSlider_6;
    QWidget *widget_4;
    QSlider *horizontalSlider_3;
    QComboBox *comboBox_2;
    QTreeWidget *treeWidget_2;
    QSlider *verticalSlider_7;
    QSlider *verticalSlider_8;
    QSlider *verticalSlider_9;
    QWidget *widget_2;
    QPushButton *pushButton_8;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QStackedWidget *stackedWidget;
    QWidget *page;
    QWidget *widget_3;
    QPushButton *pushButton_34;
    QPushButton *pushButton_35;
    QPushButton *pushButton_36;
    QLabel *label_39;
    QCheckBox *checkBox_31;
    QCheckBox *checkBox_32;
    QCheckBox *checkBox_33;
    QCheckBox *checkBox_34;
    QCheckBox *checkBox_35;
    QLabel *label_40;
    QLabel *label_43;
    QRadioButton *radioButton_25;
    QRadioButton *radioButton_26;
    QRadioButton *radioButton_27;
    QRadioButton *radioButton_28;
    QProgressBar *progressBar_13;
    QProgressBar *progressBar_14;
    QLabel *label_44;
    QLabel *label_45;
    QLineEdit *lineEdit_19;
    QLineEdit *lineEdit_20;
    QLineEdit *lineEdit_21;
    QPushButton *pushButton_37;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_4;
    QCheckBox *checkBox_3;
    QCheckBox *checkBox_4;
    QWidget *page_2;
    QWidget *widget_5;
    QSlider *horizontalSlider_2;
    QComboBox *comboBox;
    QTreeWidget *treeWidget;
    QSlider *verticalSlider_4;
    QWidget *widget_7;
    QWidget *slider_1;
    QWidget *slider_2;
    QSlider *horizontalSlider_4;
    QSlider *horizontalSlider_5;
    QWidget *slider_3;
    QWidget *slider_4;
    QWidget *page_3;
    QWidget *widget_8;
    QWidget *page_4;
    QWidget *widget_9;
    QWidget *page_5;
    QWidget *widget_10;
    QPushButton *pushButton_9;
    QPushButton *pushButton_7;

    void setupUi(QDialog *settings)
    {
        if (settings->objectName().isEmpty())
            settings->setObjectName(QStringLiteral("settings"));
        settings->resize(760, 580);
        settings->setStyleSheet(QLatin1String("QDialog#settings{\n"
"background-color: rgb(255, 255, 255);\n"
"}"));
        widget = new QWidget(settings);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(0, 0, 760, 130));
        widget->setStyleSheet(QLatin1String("QWidget#widget{\n"
"background-image: url(:/images/settings/header.png);\n"
"}"));
        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(10, 98, 100, 32));
        pushButton->setStyleSheet(QLatin1String("QPushButton{\n"
"		border-image:url(:/images/settings/setting_button.png);\n"
"		color:#ffffff;\n"
"		font: 14pt \"MS Shell Dlg 2\";\n"
"		border-top-left-radius: 3px;\n"
"		border-top-right-radius: 3px\n"
"}"));
        pushButton->setFlat(true);
        pushButton_2 = new QPushButton(widget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(680, 0, 40, 40));
        pushButton_2->setStyleSheet(QStringLiteral("QPushButton{border-image:url(:/images/settings/minibutton_normal.png);border:0px;} QPushButton:hover{border-image:url(:/images/settings/minibutton_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/settings/minibutton_on.png); position: relative;top: 1px; left: 1px;}"));
        pushButton_3 = new QPushButton(widget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(720, 0, 40, 40));
        pushButton_3->setStyleSheet(QStringLiteral("QPushButton{border-image:url(:/images/settings/closebutton_normal.png);border:0px;} QPushButton:hover{border-image:url(:/images/settings/closebutton_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/settings/closebutton_on.png); position: relative;top: 1px; left: 1px;}"));
        pushButton_4 = new QPushButton(widget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(670, 40, 90, 90));
        pushButton_4->setStyleSheet(QLatin1String("QPushButton{\n"
"		border-image:url(:/images/back_normal.png);border:0px;\n"
"} \n"
"QPushButton:hover{\n"
"		border-image:url(:/images/back_over.png);border:0px;\n"
"} \n"
"QPushButton:pressed{\n"
"		border-image:url(:/images/back_on.png); position: relative;top: 1px; left: 1px;\n"
"}"));
        widget_6 = new QWidget(settings);
        widget_6->setObjectName(QStringLiteral("widget_6"));
        widget_6->setGeometry(QRect(1050, 410, 701, 432));
        verticalSlider_6 = new QSlider(widget_6);
        verticalSlider_6->setObjectName(QStringLiteral("verticalSlider_6"));
        verticalSlider_6->setGeometry(QRect(460, 120, 22, 91));
        verticalSlider_6->setStyleSheet(QLatin1String("QSlider::groove:vertical {\n"
"    \n"
"	image: url(:/images/settings/vertical_3.png);\n"
"}\n"
" \n"
"\n"
"QSlider::handle {\n"
"	image: url(:/images/settings/vertical_blue_1.png);\n"
"}\n"
""));
        verticalSlider_6->setOrientation(Qt::Vertical);
        widget_4 = new QWidget(widget_6);
        widget_4->setObjectName(QStringLiteral("widget_4"));
        widget_4->setGeometry(QRect(389, -2, 21, 41));
        widget_4->setStyleSheet(QLatin1String("background-color: rgb(255, 255, 255);\n"
"border:none;"));
        horizontalSlider_3 = new QSlider(widget_6);
        horizontalSlider_3->setObjectName(QStringLiteral("horizontalSlider_3"));
        horizontalSlider_3->setGeometry(QRect(30, 310, 221, 32));
        horizontalSlider_3->setStyleSheet(QLatin1String("QSlider::groove:horizontal {\n"
"    \n"
"	image: url(:/images/settings/sliderbar1.png);\n"
"}\n"
" \n"
"\n"
"QSlider::handle {\n"
"	image: url(:/images/settings/horizental_yellow_2.png);\n"
"}\n"
""));
        horizontalSlider_3->setOrientation(Qt::Horizontal);
        comboBox_2 = new QComboBox(widget_6);
        comboBox_2->setObjectName(QStringLiteral("comboBox_2"));
        comboBox_2->setGeometry(QRect(380, 10, 151, 22));
        QPalette palette;
        QBrush brush(QColor(84, 110, 122, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        QBrush brush1(QColor(255, 255, 255, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush1);
        palette.setBrush(QPalette::Active, QPalette::Text, brush);
        palette.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush1);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        comboBox_2->setPalette(palette);
        comboBox_2->setAutoFillBackground(false);
        comboBox_2->setStyleSheet(QLatin1String(" QComboBox {\n"
"    border-style: solid;\n"
"border:2px;\n"
"    border-radius: 0px;\n"
"background-color: rgb(255, 255, 255);\n"
"color: #546e7a;\n"
"font:11pt;\n"
" }\n"
"\n"
"QComboBox QAbstractItemView {\n"
"     border: 1px solid darkgray;\n"
"     selection-background-color: #60b9ff;\n"
"	 color:546e7a;\n"
" }"));
        comboBox_2->setDuplicatesEnabled(false);
        comboBox_2->setFrame(true);
        treeWidget_2 = new QTreeWidget(widget_6);
        treeWidget_2->headerItem()->setText(0, QString());
        QFont font;
        font.setPointSize(10);
        QTreeWidgetItem *__qtreewidgetitem = new QTreeWidgetItem(treeWidget_2);
        QTreeWidgetItem *__qtreewidgetitem1 = new QTreeWidgetItem(__qtreewidgetitem);
        __qtreewidgetitem1->setFlags(Qt::ItemIsSelectable|Qt::ItemIsEditable|Qt::ItemIsDragEnabled|Qt::ItemIsUserCheckable|Qt::ItemIsEnabled);
        __qtreewidgetitem1->setText(0, QStringLiteral(" TreeView"));
        __qtreewidgetitem1->setFont(0, font);
        new QTreeWidgetItem(__qtreewidgetitem);
        new QTreeWidgetItem(__qtreewidgetitem);
        new QTreeWidgetItem(__qtreewidgetitem);
        new QTreeWidgetItem(__qtreewidgetitem);
        QTreeWidgetItem *__qtreewidgetitem2 = new QTreeWidgetItem(__qtreewidgetitem);
        QTreeWidgetItem *__qtreewidgetitem3 = new QTreeWidgetItem(__qtreewidgetitem2);
        new QTreeWidgetItem(__qtreewidgetitem3);
        QTreeWidgetItem *__qtreewidgetitem4 = new QTreeWidgetItem(__qtreewidgetitem);
        new QTreeWidgetItem(__qtreewidgetitem4);
        new QTreeWidgetItem(__qtreewidgetitem4);
        treeWidget_2->setObjectName(QStringLiteral("treeWidget_2"));
        treeWidget_2->setGeometry(QRect(19, 0, 331, 301));
        treeWidget_2->setStyleSheet(QLatin1String("\n"
" QTreeView{\n"
"		border: 1px solid #ffffff;\n"
"		color:#71858e;\n"
"		font:12pt;\n"
"}\n"
"/*QTreeView::branch:closed:has-children{\n"
"   border-image: url(:/images/settings/icon11.png) 0;\n"
" }\n"
" \n"
"QTreeView::branch:open:has-children{\n"
"   border-image: url(:/images/settings/icon22.png) 0; \n"
"}*/"));
        verticalSlider_7 = new QSlider(widget_6);
        verticalSlider_7->setObjectName(QStringLiteral("verticalSlider_7"));
        verticalSlider_7->setGeometry(QRect(451, 252, 41, 101));
        verticalSlider_7->setStyleSheet(QLatin1String("QSlider::groove:vertical {\n"
"    \n"
"	image: url(:/images/settings/vertical_2.png);\n"
"}\n"
" \n"
"\n"
"QSlider::handle {\n"
"	image: url(:/images/settings/vertical_blue_1.png);\n"
"}\n"
""));
        verticalSlider_7->setOrientation(Qt::Vertical);
        verticalSlider_8 = new QSlider(widget_6);
        verticalSlider_8->setObjectName(QStringLiteral("verticalSlider_8"));
        verticalSlider_8->setGeometry(QRect(549, 128, 22, 101));
        verticalSlider_8->setStyleSheet(QLatin1String("QSlider::groove:vertical {\n"
"    \n"
"	image: url(:/images/settings/vertical_1.png);\n"
"}\n"
" \n"
"\n"
"QSlider::handle {\n"
"	image: url(:/images/settings/vertical_yellow_2.png);\n"
"}\n"
""));
        verticalSlider_8->setOrientation(Qt::Vertical);
        verticalSlider_9 = new QSlider(widget_6);
        verticalSlider_9->setObjectName(QStringLiteral("verticalSlider_9"));
        verticalSlider_9->setGeometry(QRect(491, 92, 41, 261));
        verticalSlider_9->setStyleSheet(QLatin1String("QSlider::groove:vertical {\n"
"    \n"
"	image: url(:/images/settings/vertical_2.png);\n"
"}\n"
" \n"
"\n"
"QSlider::handle {\n"
"	image: url(:/images/settings/vertical_yellow_1.png);\n"
"}\n"
""));
        verticalSlider_9->setOrientation(Qt::Vertical);
        widget_2 = new QWidget(settings);
        widget_2->setObjectName(QStringLiteral("widget_2"));
        widget_2->setGeometry(QRect(10, 140, 740, 430));
        widget_2->setStyleSheet(QLatin1String("QWidget#widget_2{\n"
"	background-color: #f6f6f6;\n"
"}"));
        pushButton_8 = new QPushButton(widget_2);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));
        pushButton_8->setGeometry(QRect(0, 139, 189, 48));
        pushButton_8->setStyleSheet(QLatin1String("QPushButton{\n"
"		border-image:url(:/images/settings/tab_sandbox_normal.png);border:0px;\n"
"} \n"
"QPushButton:hover{\n"
"		border-image:url(:/images/settings/tab_sandbox_over.png);border:0px\n"
"} \n"
"QPushButton:pressed{\n"
"		border-image:url(:/images/settings/tab_sandbox_on.png); position: relative;top: 1px; left: 1px;\n"
"}\n"
"QPushButton:checked{\n"
"		border-image:url(:/images/settings/tab_sandbox_on.png); position: relative;top: 1px; left: 1px;\n"
"}"));
        pushButton_8->setCheckable(true);
        pushButton_8->setFlat(true);
        pushButton_5 = new QPushButton(widget_2);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(0, -5, 189, 48));
        pushButton_5->setStyleSheet(QLatin1String("/*QPushButton{\n"
"		border-image:url(:/images/settings/tab_phonix_normal.png);border:0px;\n"
"}\n"
"QPushButton:clicked{\n"
"		border-image:url(:/images/settings/tab_phonix_on.png);border:0px\n"
"} \n"
"QPushButton:hover{\n"
"		border-image:url(:/images/settings/tab_phonix_over.png);border:0px\n"
"} \n"
"QPushButton:pressed{\n"
"		border-image:url(:/images/settings/tab_phonix_on.png); position: relative;top: 1px; left: 1px;\n"
"}\n"
"QPushButton:cheked{\n"
"		border-image:url(:/images/settings/tab_phonix_on.png);border:0px\n"
"} */\n"
"QPushButton {\n"
"border-image:url(:/images/settings/tab_phonix_normal.png);border:0px;\n"
"}\n"
"QPushButton:checked{\n"
"border-image: url(:/images/settings/tab_phonix_on.png);\n"
"color: rgb(255, 255, 255);\n"
"}\n"
""));
        pushButton_5->setCheckable(true);
        pushButton_5->setChecked(true);
        pushButton_5->setAutoDefault(true);
        pushButton_5->setFlat(true);
        pushButton_6 = new QPushButton(widget_2);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setGeometry(QRect(0, 43, 189, 48));
        pushButton_6->setStyleSheet(QLatin1String("QPushButton{\n"
"		border-image:url(:/images/settings/tab_server_normal.png);border:0px;\n"
"} \n"
"QPushButton:hover{\n"
"		border-image:url(:/images/settings/tab_server_over.png);border:0px\n"
"} \n"
"QPushButton:pressed{\n"
"		border-image:url(:/images/settings/tab_server_on.png); position: relative;top: 1px; left: 1px;\n"
"}\n"
"QPushButton:checked{\n"
"		border-image:url(:/images/settings/tab_server_on.png); position: relative;top: 1px; left: 1px;\n"
"}"));
        pushButton_6->setCheckable(true);
        pushButton_6->setFlat(true);
        stackedWidget = new QStackedWidget(widget_2);
        stackedWidget->setObjectName(QStringLiteral("stackedWidget"));
        stackedWidget->setGeometry(QRect(188, -5, 553, 432));
        page = new QWidget();
        page->setObjectName(QStringLiteral("page"));
        widget_3 = new QWidget(page);
        widget_3->setObjectName(QStringLiteral("widget_3"));
        widget_3->setGeometry(QRect(1, 0, 553, 432));
        widget_3->setStyleSheet(QLatin1String("QWidget#widget_2{\n"
"border:none;\n"
"background-image: url(:/images/settings/background.png);\n"
"}"));
        pushButton_34 = new QPushButton(widget_3);
        pushButton_34->setObjectName(QStringLiteral("pushButton_34"));
        pushButton_34->setGeometry(QRect(179, 392, 120, 40));
        pushButton_34->setStyleSheet(QLatin1String("QPushButton{\n"
"		border-image:url(:/images/settings/rectangle_on.png);border:0px; color: rgb(255, 255, 255);font: 12pt \"MS Shell Dlg 2\";\n"
"		border-top-left-radius: 3px;\n"
"		border-top-right-radius: 3px\n"
"} \n"
"QPushButton:hover{\n"
"		border-image:url(:/images/settings/rectangle_on.png);border:0px; color: rgb(255, 255, 255);font: 12pt \"MS Shell Dlg 2\";\n"
"		border-top-left-radius: 3px;\n"
"		border-top-right-radius: 3px\n"
"} \n"
"QPushButton:pressed{\n"
"		border-image:url(:/images/settings/rectangle_on.png); position: relative;top: 1px; left: 1px; color: rgb(255, 255, 255);font: 12pt \"MS Shell Dlg 2\";\n"
"		border-top-left-radius: 3px;\n"
"		border-top-right-radius: 3px\n"
"}"));
        pushButton_34->setFlat(true);
        pushButton_35 = new QPushButton(widget_3);
        pushButton_35->setObjectName(QStringLiteral("pushButton_35"));
        pushButton_35->setGeometry(QRect(309, 392, 120, 40));
        pushButton_35->setStyleSheet(QLatin1String("QPushButton{\n"
"		border-image:url(:/images/settings/rectangle_over.png);border:0px; color: rgb(255, 255, 255);font: 12pt \"MS Shell Dlg 2\";\n"
"		border-top-left-radius: 3px;\n"
"		border-top-right-radius: 3px\n"
"} \n"
"QPushButton:hover{\n"
"		border-image:url(:/images/settings/rectangle_over.png);border:0px; color: rgb(255, 255, 255);font: 12pt \"MS Shell Dlg 2\";\n"
"		border-top-left-radius: 3px;\n"
"		border-top-right-radius: 3px\n"
"} \n"
"QPushButton:pressed{\n"
"		border-image:url(:/images/settings/rectangle_over.png); position: relative;top: 1px; left: 1px; color: rgb(255, 255, 255);font: 12pt \"MS Shell Dlg 2\";\n"
"		border-top-left-radius: 3px;\n"
"		border-top-right-radius: 3px\n"
"}"));
        pushButton_35->setFlat(true);
        pushButton_36 = new QPushButton(widget_3);
        pushButton_36->setObjectName(QStringLiteral("pushButton_36"));
        pushButton_36->setGeometry(QRect(439, 391, 120, 40));
        pushButton_36->setStyleSheet(QLatin1String("QPushButton{\n"
"		border-image:url(:/images/settings/rectangle_normal.png);border:0px; color: rgb(255, 255, 255);font: 12pt \"MS Shell Dlg 2\";\n"
"		border-top-left-radius: 3px;\n"
"		border-top-right-radius: 3px\n"
"} \n"
"QPushButton:hover{\n"
"		border-image:url(:/images/settings/rectangle_normal.png);border:0px; color: rgb(255, 255, 255);font: 12pt \"MS Shell Dlg 2\";\n"
"		border-top-left-radius: 3px;\n"
"		border-top-right-radius: 3px\n"
"} \n"
"QPushButton:pressed{\n"
"		border-image:url(:/images/settings/rectangle_normal.png); position: relative;top: 1px; left: 1px; color: rgb(255, 255, 255);font: 12pt \"MS Shell Dlg 2\";\n"
"		border-top-left-radius: 3px;\n"
"		border-top-right-radius: 3px\n"
"}"));
        pushButton_36->setFlat(true);
        label_39 = new QLabel(widget_3);
        label_39->setObjectName(QStringLiteral("label_39"));
        label_39->setGeometry(QRect(17, 17, 400, 69));
        label_39->setStyleSheet(QLatin1String("background-image: url(:/images/settings/text.png);\n"
"background-color: rgb(246, 246, 246);"));
        checkBox_31 = new QCheckBox(widget_3);
        checkBox_31->setObjectName(QStringLiteral("checkBox_31"));
        checkBox_31->setGeometry(QRect(20, 96, 81, 21));
        checkBox_31->setStyleSheet(QLatin1String("\n"
"QCheckBox::indicator:unchecked{\n"
"	\n"
"    image: url(:/images/settings/uncheck_1.png);\n"
"}\n"
"QCheckBox::indicator:checked{\n"
"	\n"
"    image: url(:/images/settings/check_1.png);\n"
"}"));
        checkBox_31->setChecked(true);
        checkBox_32 = new QCheckBox(widget_3);
        checkBox_32->setObjectName(QStringLiteral("checkBox_32"));
        checkBox_32->setGeometry(QRect(20, 126, 81, 21));
        checkBox_32->setStyleSheet(QLatin1String("QCheckBox::indicator:unchecked{\n"
"	\n"
"    image: url(:/images/settings/uncheck_2.png);\n"
"}\n"
"QCheckBox::indicator:checked{\n"
"	\n"
"    image: url(:/images/settings/check_2.png);\n"
"}"));
        checkBox_32->setChecked(false);
        checkBox_33 = new QCheckBox(widget_3);
        checkBox_33->setObjectName(QStringLiteral("checkBox_33"));
        checkBox_33->setGeometry(QRect(130, 126, 81, 21));
        checkBox_33->setStyleSheet(QLatin1String("QCheckBox::indicator:unchecked{\n"
"	\n"
"    image: url(:/images/settings/check_3.png);\n"
"}\n"
"QCheckBox::indicator:checked{\n"
"	\n"
"    image: url(:/images/settings/uncheck_3.png);\n"
"}"));
        checkBox_33->setChecked(false);
        checkBox_34 = new QCheckBox(widget_3);
        checkBox_34->setObjectName(QStringLiteral("checkBox_34"));
        checkBox_34->setEnabled(false);
        checkBox_34->setGeometry(QRect(20, 156, 81, 21));
        checkBox_34->setStyleSheet(QLatin1String("QCheckBox::indicator:unchecked{\n"
"	\n"
"    image: url(:/images/settings/check_3.png);\n"
"}\n"
"QCheckBox::indicator:checked{\n"
"	\n"
"    image: url(:/images/settings/uncheck_3.png);\n"
"}"));
        checkBox_35 = new QCheckBox(widget_3);
        checkBox_35->setObjectName(QStringLiteral("checkBox_35"));
        checkBox_35->setEnabled(false);
        checkBox_35->setGeometry(QRect(130, 156, 81, 21));
        checkBox_35->setStyleSheet(QLatin1String("QCheckBox::indicator:unchecked{\n"
"	\n"
"    image: url(:/images/settings/check_4.png);\n"
"}\n"
"QCheckBox::indicator:checked{\n"
"	\n"
"    image: url(:/images/settings/uncheck_5.png);\n"
"}"));
        checkBox_35->setChecked(true);
        label_40 = new QLabel(widget_3);
        label_40->setObjectName(QStringLiteral("label_40"));
        label_40->setGeometry(QRect(20, 193, 40, 8));
        label_40->setStyleSheet(QLatin1String("\n"
"background-image: url(:/images/settings/success.png);"));
        label_43 = new QLabel(widget_3);
        label_43->setObjectName(QStringLiteral("label_43"));
        label_43->setGeometry(QRect(200, 193, 23, 8));
        label_43->setStyleSheet(QLatin1String("\n"
"background-image: url(:/images/settings/error.png);"));
        radioButton_25 = new QRadioButton(widget_3);
        radioButton_25->setObjectName(QStringLiteral("radioButton_25"));
        radioButton_25->setEnabled(true);
        radioButton_25->setGeometry(QRect(20, 243, 82, 21));
        radioButton_25->setStyleSheet(QLatin1String("\n"
"QRadioButton::indicator:unchecked{\n"
"	\n"
"    image: url(:/images/settings/enable_black.png);\n"
"}\n"
"QRadioButton::indicator:checked{\n"
"	\n"
"    image: url(:/images/settings/disabel_black.png);\n"
"}\n"
"QRadioButton::indicator:unchecked:disabled{\n"
"	\n"
"    image: url(:/images/settings/disable_black.png);\n"
"}\n"
"QRadioButton::indicator:checked:disabled{\n"
"	\n"
"    image: url(:/images/settings/check_disable_black.png);\n"
"}"));
        radioButton_25->setCheckable(true);
        radioButton_25->setChecked(false);
        radioButton_26 = new QRadioButton(widget_3);
        radioButton_26->setObjectName(QStringLiteral("radioButton_26"));
        radioButton_26->setGeometry(QRect(130, 274, 82, 20));
        radioButton_26->setStyleSheet(QLatin1String("QRadioButton::indicator{\n"
"	\n"
"    image: url(:/images/settings/radio_2.png);\n"
"}"));
        radioButton_27 = new QRadioButton(widget_3);
        radioButton_27->setObjectName(QStringLiteral("radioButton_27"));
        radioButton_27->setEnabled(true);
        radioButton_27->setGeometry(QRect(130, 243, 82, 21));
        radioButton_27->setStyleSheet(QLatin1String("QRadioButton::indicator:unchecked{\n"
"	\n"
"    image: url(:/images/settings/disable_red.png);\n"
"}\n"
"QRadioButton::indicator:checked{\n"
"	\n"
"    image: url(:/images/settings/radio_1.png);\n"
"}\n"
"QRadioButton::indicator:checked:disabled{\n"
"	\n"
"    image: url(:/images/settings/radio_2.png);\n"
"}\n"
"QRadioButton::indicator:unchecked:disabled{\n"
"	\n"
"    image: url(:/images/settings/uncheck_disable_red.png);\n"
"}"));
        radioButton_27->setChecked(false);
        radioButton_28 = new QRadioButton(widget_3);
        radioButton_28->setObjectName(QStringLiteral("radioButton_28"));
        radioButton_28->setEnabled(false);
        radioButton_28->setGeometry(QRect(20, 274, 82, 20));
        radioButton_28->setStyleSheet(QLatin1String("QRadioButton::indicator{\n"
"	\n"
"    image: url(:/images/settings/radio_3.png);\n"
"}"));
        progressBar_13 = new QProgressBar(widget_3);
        progressBar_13->setObjectName(QStringLiteral("progressBar_13"));
        progressBar_13->setGeometry(QRect(20, 320, 501, 6));
        progressBar_13->setStyleSheet(QLatin1String("\n"
"QProgressBar {\n"
"    border: 0px solid grey;\n"
"    border-radius: 15px;\n"
"	background:#fbe9e7;\n"
"}\n"
"QProgressBar::chunk {\n"
"    background: #ff8135;\n"
"    width: 20px;\n"
"}"));
        progressBar_13->setValue(24);
        progressBar_13->setTextVisible(false);
        progressBar_14 = new QProgressBar(widget_3);
        progressBar_14->setObjectName(QStringLiteral("progressBar_14"));
        progressBar_14->setGeometry(QRect(20, 337, 501, 6));
        progressBar_14->setStyleSheet(QLatin1String("QProgressBar {\n"
"    border: 0px solid grey;\n"
"    border-radius: 3px;\n"
"	background:#e3f2fd;\n"
"border-bottom-right-radius: 7px;\n"
"border-bottom-left-radius: 7px;\n"
"border-top-right-radius: 7px;\n"
"border-top-left-radius: 7px;\n"
"}\n"
"QProgressBar::chunk {\n"
"    background-color: #82b1ff;\n"
"    width: 50px;\n"
"}\n"
"\n"
""));
        progressBar_14->setValue(24);
        progressBar_14->setTextVisible(false);
        label_44 = new QLabel(widget_3);
        label_44->setObjectName(QStringLiteral("label_44"));
        label_44->setGeometry(QRect(155, 210, 20, 13));
        label_44->setStyleSheet(QLatin1String("\n"
"background-image: url(:/images/settings/state_succese.png);"));
        label_45 = new QLabel(widget_3);
        label_45->setObjectName(QStringLiteral("label_45"));
        label_45->setGeometry(QRect(335, 206, 16, 16));
        label_45->setStyleSheet(QLatin1String("\n"
"background-image: url(:/images/settings/state_error.png);"));
        lineEdit_19 = new QLineEdit(widget_3);
        lineEdit_19->setObjectName(QStringLiteral("lineEdit_19"));
        lineEdit_19->setEnabled(true);
        lineEdit_19->setGeometry(QRect(393, 137, 141, 30));
        lineEdit_19->setFont(font);
        lineEdit_19->setStyleSheet(QLatin1String("background-color: rgb(255, 255, 255);\n"
"color: rgb(204, 204, 204);\n"
"border:1px solid #cfd8dc;\n"
"\n"
"font-size: 10pt;\n"
"	"));
        lineEdit_20 = new QLineEdit(widget_3);
        lineEdit_20->setObjectName(QStringLiteral("lineEdit_20"));
        lineEdit_20->setGeometry(QRect(393, 175, 141, 30));
        lineEdit_20->setFont(font);
        lineEdit_20->setStyleSheet(QLatin1String("color: #9aa7ad;\n"
"border:1px solid #40c4ff;\n"
"\n"
"font-size: 10pt;"));
        lineEdit_21 = new QLineEdit(widget_3);
        lineEdit_21->setObjectName(QStringLiteral("lineEdit_21"));
        lineEdit_21->setGeometry(QRect(393, 214, 141, 30));
        lineEdit_21->setFont(font);
        lineEdit_21->setStyleSheet(QLatin1String("border:1px solid #ff5252;\n"
"color: rgb(255, 98, 98);\n"
"font-size: 10pt;"));
        pushButton_37 = new QPushButton(widget_3);
        pushButton_37->setObjectName(QStringLiteral("pushButton_37"));
        pushButton_37->setGeometry(QRect(48, 391, 120, 40));
        pushButton_37->setStyleSheet(QLatin1String("QPushButton{\n"
"		border-image:url(:/images/settings/rectangle_gray.png);border:0px; color: rgb(187, 194, 198);font: 12pt \"MS Shell Dlg 2\";\n"
"		border-top-left-radius: 3px;\n"
"		border-top-right-radius: 3px\n"
"} \n"
"QPushButton:hover{\n"
"		border-image:url(:/images/settings/rectangle_gray.png);border:0px; color: rgb(187, 194, 198);font: 12pt \"MS Shell Dlg 2\";\n"
"		border-top-left-radius: 3px;\n"
"		border-top-right-radius: 3px\n"
"} \n"
"QPushButton:pressed{\n"
"		border-image:url(:/images/settings/rectangle_gray.png); position: relative;top: 1px; left: 1px; color: rgb(187, 194, 198);font: 12pt \"MS Shell Dlg 2\";\n"
"		border-top-left-radius: 3px;\n"
"		border-top-right-radius: 3px\n"
"}"));
        pushButton_37->setFlat(true);
        lineEdit_3 = new QLineEdit(widget_3);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(20, 207, 131, 20));
        lineEdit_3->setStyleSheet(QLatin1String("QLineEdit {\n"
"    border-top: none;\n"
"border-left: none;\n"
"border-right: none;\n"
"border-bottom: 2px solid #2979ff;\n"
"    border-radius: 0px;\n"
"    padding: 0 8px;\n"
"    background: #f6f6f6;\n"
"    /*selection-background-color: darkgray;*/\n"
"}"));
        lineEdit_4 = new QLineEdit(widget_3);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(200, 206, 131, 20));
        lineEdit_4->setStyleSheet(QLatin1String("QLineEdit {\n"
"    border-top: none;\n"
"border-left: none;\n"
"border-right: none;\n"
"border-bottom: 2px solid #ff5252;\n"
"    border-radius: 0px;\n"
"    padding: 0 8px;\n"
"    background: #f6f6f6;\n"
"    /*selection-background-color: darkgray;*/\n"
"}"));
        checkBox_3 = new QCheckBox(widget_3);
        checkBox_3->setObjectName(QStringLiteral("checkBox_3"));
        checkBox_3->setGeometry(QRect(450, 55, 90, 44));
        checkBox_3->setStyleSheet(QLatin1String("\n"
"QCheckBox::indicator::unchecked {\n"
"    image: url(:/images/settings/switch_1_off.png);\n"
"}\n"
"\n"
"\n"
"QCheckBox::indicator:unchecked:pressed {\n"
"    image: url(:/images/settings/switch_1_on_press.png);\n"
"}\n"
"\n"
"QCheckBox::indicator::checked {\n"
"    image: url(:/images/settings/switch_1_on.png);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked:pressed {\n"
"    image: url(:/images/settings/switch_1_off_press.png);\n"
"}\n"
""));
        checkBox_4 = new QCheckBox(widget_3);
        checkBox_4->setObjectName(QStringLiteral("checkBox_4"));
        checkBox_4->setGeometry(QRect(466, 100, 52, 32));
        checkBox_4->setStyleSheet(QLatin1String("\n"
"QCheckBox::indicator::unchecked {\n"
"    image: url(:/images/settings/switch_2_off.png);\n"
"}\n"
"\n"
"\n"
"QCheckBox::indicator:unchecked:pressed {\n"
"    image: url(:/images/settings/switch_2_press.png);\n"
"}\n"
"\n"
"QCheckBox::indicator::checked {\n"
"    image: url(:/images/settings/switch_2_on.png);\n"
"}\n"
"\n"
"QCheckBox::indicator:checked:pressed {\n"
"    image: url(:/images/settings/switch_2_off_press.png);\n"
"}\n"
""));
        stackedWidget->addWidget(page);
        page_2 = new QWidget();
        page_2->setObjectName(QStringLiteral("page_2"));
        widget_5 = new QWidget(page_2);
        widget_5->setObjectName(QStringLiteral("widget_5"));
        widget_5->setGeometry(QRect(0, 0, 701, 432));
        horizontalSlider_2 = new QSlider(widget_5);
        horizontalSlider_2->setObjectName(QStringLiteral("horizontalSlider_2"));
        horizontalSlider_2->setGeometry(QRect(20, 365, 221, 21));
        horizontalSlider_2->setStyleSheet(QLatin1String("\n"
"\n"
"QSlider::groove:horizontal { \n"
"	background-image:  url(:/images/settings/sliderbar2.png); \n"
"	height:5px;\n"
"	left: 0px; \n"
"	right:0px; \n"
"} \n"
"QSlider::handle:horizontal {\n"
"	height:25px;\n"
"	width:25px;  \n"
"	background-image:  url(:/images/settings/vertical_yellow_2.png); \n"
"	left: 5px; \n"
"	\n"
"	top:-9px;\n"
"	bottom:-7px; \n"
"border: none;\n"
"}\n"
" QSlider::sub-page:horizontal {\n"
"	 background-image: url(:/images/settings/sliderbar1.png);\n"
"	left: 0px; \n"
"	right:0px;  \n"
"}\n"
"\n"
""));
        horizontalSlider_2->setOrientation(Qt::Horizontal);
        comboBox = new QComboBox(widget_5);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(383, 10, 151, 22));
        QPalette palette1;
        palette1.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette1.setBrush(QPalette::Active, QPalette::Button, brush1);
        palette1.setBrush(QPalette::Active, QPalette::Text, brush);
        palette1.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette1.setBrush(QPalette::Active, QPalette::Base, brush1);
        palette1.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette1.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette1.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::Base, brush1);
        palette1.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette1.setBrush(QPalette::Disabled, QPalette::WindowText, brush);
        palette1.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette1.setBrush(QPalette::Disabled, QPalette::Text, brush);
        palette1.setBrush(QPalette::Disabled, QPalette::ButtonText, brush);
        palette1.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette1.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        comboBox->setPalette(palette1);
        comboBox->setAutoFillBackground(false);
        comboBox->setStyleSheet(QLatin1String(" QComboBox {\n"
"    border-style: solid;\n"
"border:2px;\n"
"    border-radius: 0px;\n"
"background-color: rgb(255, 255, 255);\n"
"color: #546e7a;\n"
"font:11pt;\n"
" }\n"
"\n"
"QComboBox QAbstractItemView {\n"
"     border: 1px solid darkgray;\n"
"     selection-background-color: #60b9ff;\n"
"	 color:546e7a;\n"
" }"));
        comboBox->setDuplicatesEnabled(false);
        comboBox->setFrame(true);
        treeWidget = new QTreeWidget(widget_5);
        treeWidget->headerItem()->setText(0, QString());
        QTreeWidgetItem *__qtreewidgetitem5 = new QTreeWidgetItem(treeWidget);
        new QTreeWidgetItem(__qtreewidgetitem5);
        new QTreeWidgetItem(__qtreewidgetitem5);
        QTreeWidgetItem *__qtreewidgetitem6 = new QTreeWidgetItem(__qtreewidgetitem5);
        QTreeWidgetItem *__qtreewidgetitem7 = new QTreeWidgetItem(__qtreewidgetitem6);
        new QTreeWidgetItem(__qtreewidgetitem7);
        QTreeWidgetItem *__qtreewidgetitem8 = new QTreeWidgetItem(__qtreewidgetitem5);
        new QTreeWidgetItem(__qtreewidgetitem8);
        new QTreeWidgetItem(__qtreewidgetitem8);
        treeWidget->setObjectName(QStringLiteral("treeWidget"));
        treeWidget->setGeometry(QRect(18, 0, 341, 271));
        treeWidget->setStyleSheet(QLatin1String("\n"
" QTreeView{\n"
"		border-style:1px,solid #ffffff ;\n"
"		color:#71858e;\n"
"		font:12pt;\n"
"}\n"
"/*QTreeView::branch:closed:has-children{\n"
"   border-image: url(:/images/settings/icon11.png) 0;\n"
" }\n"
" \n"
"QTreeView::branch:open:has-children{\n"
"   border-image: url(:/images/settings/icon22.png) 0; \n"
"}*/"));
        verticalSlider_4 = new QSlider(widget_5);
        verticalSlider_4->setObjectName(QStringLiteral("verticalSlider_4"));
        verticalSlider_4->setGeometry(QRect(516, 136, 31, 221));
        verticalSlider_4->setStyleSheet(QLatin1String("QSlider::groove:vertical { \n"
"	background-image:  url(:/images/settings/vertical_3.png); \n"
"	width:5px;\n"
"	left: 0px; \n"
"	right:0px; \n"
"} \n"
"QSlider::handle:vertical {\n"
"	height:27px;\n"
"	width:27px;  \n"
"	background-image:  url(:/images/settings/vertical_blue_2.png); \n"
"	left: -9px; \n"
"	right: -10px;\n"
"	top:10px;\n"
"	bottom:-4px; \n"
"border: none;\n"
"}\n"
" QSlider::sub-page:vertical {\n"
"	 background-image: url(:/images/settings/vertical_2.png);\n"
"	left: 0px; \n"
"	right:0px;  \n"
"}\n"
""));
        verticalSlider_4->setOrientation(Qt::Vertical);
        widget_7 = new QWidget(widget_5);
        widget_7->setObjectName(QStringLiteral("widget_7"));
        widget_7->setGeometry(QRect(358, 0, 4, 30));
        widget_7->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));
        slider_1 = new QWidget(widget_5);
        slider_1->setObjectName(QStringLiteral("slider_1"));
        slider_1->setGeometry(QRect(17, 389, 311, 41));
        slider_2 = new QWidget(widget_5);
        slider_2->setObjectName(QStringLiteral("slider_2"));
        slider_2->setGeometry(QRect(476, 108, 41, 271));
        horizontalSlider_4 = new QSlider(widget_5);
        horizontalSlider_4->setObjectName(QStringLiteral("horizontalSlider_4"));
        horizontalSlider_4->setGeometry(QRect(20, 330, 221, 20));
        horizontalSlider_4->setStyleSheet(QLatin1String("\n"
"\n"
"QSlider::groove:horizontal { \n"
"	background-image:  url(:/images/settings/sliderbar2.png); \n"
"	height:5px;\n"
"	left: 0px; \n"
"	right:0px; \n"
"} \n"
"QSlider::handle:horizontal {\n"
"	height:25px;\n"
"	width:19px;  \n"
"	background-image:  url(:/images/slider_yellow_handle.png); \n"
"	left: 5px; \n"
"	\n"
"	top:-9px;\n"
"	bottom:-7px; \n"
"border: none;\n"
"}\n"
" QSlider::sub-page:horizontal {\n"
"	 background-image: url(:/images/settings/sliderbar1.png);\n"
"	left: 0px; \n"
"	right:0px;  \n"
"}\n"
"\n"
""));
        horizontalSlider_4->setOrientation(Qt::Horizontal);
        horizontalSlider_5 = new QSlider(widget_5);
        horizontalSlider_5->setObjectName(QStringLiteral("horizontalSlider_5"));
        horizontalSlider_5->setGeometry(QRect(20, 290, 221, 20));
        horizontalSlider_5->setStyleSheet(QLatin1String("\n"
"\n"
"QSlider::groove:horizontal { \n"
"	background-image:  url(:/images/settings/sliderbar2.png); \n"
"	height:3px;\n"
"	left: 0px; \n"
"	right:0px; \n"
"} \n"
"QSlider::handle:horizontal {\n"
"	height:25px;\n"
"	width:19px;  \n"
"	background-image:  url(:/images/slider_yellow_handle.png); \n"
"	left: 5px; \n"
"	\n"
"	top:-9px;\n"
"	bottom:-7px; \n"
"border: none;\n"
"}\n"
" QSlider::sub-page:horizontal {\n"
"	 background-image: url(:/images/settings/sliderbar1.png);\n"
"	left: 0px; \n"
"	right:0px;  \n"
"}\n"
"\n"
""));
        horizontalSlider_5->setOrientation(Qt::Horizontal);
        slider_3 = new QWidget(widget_5);
        slider_3->setObjectName(QStringLiteral("slider_3"));
        slider_3->setGeometry(QRect(250, 320, 221, 31));
        slider_4 = new QWidget(widget_5);
        slider_4->setObjectName(QStringLiteral("slider_4"));
        slider_4->setGeometry(QRect(250, 350, 221, 31));
        stackedWidget->addWidget(page_2);
        page_3 = new QWidget();
        page_3->setObjectName(QStringLiteral("page_3"));
        widget_8 = new QWidget(page_3);
        widget_8->setObjectName(QStringLiteral("widget_8"));
        widget_8->setGeometry(QRect(0, 0, 551, 431));
        stackedWidget->addWidget(page_3);
        page_4 = new QWidget();
        page_4->setObjectName(QStringLiteral("page_4"));
        widget_9 = new QWidget(page_4);
        widget_9->setObjectName(QStringLiteral("widget_9"));
        widget_9->setGeometry(QRect(0, 0, 551, 431));
        stackedWidget->addWidget(page_4);
        page_5 = new QWidget();
        page_5->setObjectName(QStringLiteral("page_5"));
        widget_10 = new QWidget(page_5);
        widget_10->setObjectName(QStringLiteral("widget_10"));
        widget_10->setGeometry(QRect(0, 0, 551, 431));
        stackedWidget->addWidget(page_5);
        pushButton_9 = new QPushButton(widget_2);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));
        pushButton_9->setGeometry(QRect(0, 187, 189, 48));
        pushButton_9->setStyleSheet(QLatin1String("QPushButton{\n"
"		border-image:url(:/images/settings/tab_detection_normal.png);border:0px;\n"
"} \n"
"QPushButton:hover{\n"
"		border-image:url(:/images/settings/tab_detection_over.png);border:0px\n"
"} \n"
"QPushButton:pressed{\n"
"		border-image:url(:/images/settings/tab_detection_on.png); position: relative;top: 1px; left: 1px;\n"
"}\n"
"QPushButton:checked{\n"
"		border-image:url(:/images/settings/tab_detection_on.png); position: relative;top: 1px; left: 1px;\n"
"}"));
        pushButton_9->setCheckable(true);
        pushButton_9->setFlat(true);
        pushButton_7 = new QPushButton(widget_2);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        pushButton_7->setGeometry(QRect(0, 91, 189, 48));
        pushButton_7->setStyleSheet(QLatin1String("QPushButton{\n"
"		border-image:url(:/images/settings/tab_firewall_normal.png);border:0px;\n"
"} \n"
"QPushButton:hover{\n"
"		border-image:url(:/images/settings/tab_firewall_over.png);border:0px\n"
"} \n"
"QPushButton:pressed{\n"
"		border-image:url(:/images/settings/tab_firewall_on.png); position: relative;top: 1px; left: 1px;\n"
"}\n"
"QPushButton:checked{\n"
"		border-image:url(:/images/settings/tab_firewall_on.png); position: relative;top: 1px; left: 1px;\n"
"}"));
        pushButton_7->setCheckable(true);
        pushButton_7->setFlat(true);

        retranslateUi(settings);

        QMetaObject::connectSlotsByName(settings);
    } // setupUi

    void retranslateUi(QDialog *settings)
    {
        settings->setWindowTitle(QApplication::translate("settings", "Dialog", Q_NULLPTR));
        pushButton->setText(QApplication::translate("settings", "Settings", Q_NULLPTR));
        pushButton_2->setText(QString());
        pushButton_3->setText(QString());
        pushButton_4->setText(QString());
        comboBox_2->clear();
        comboBox_2->insertItems(0, QStringList()
         << QApplication::translate("settings", "ComboBox1", Q_NULLPTR)
         << QApplication::translate("settings", "ComboBox2", Q_NULLPTR)
         << QApplication::translate("settings", "ComboBox3", Q_NULLPTR)
        );

        const bool __sortingEnabled = treeWidget_2->isSortingEnabled();
        treeWidget_2->setSortingEnabled(false);
        QTreeWidgetItem *___qtreewidgetitem = treeWidget_2->topLevelItem(0);
        ___qtreewidgetitem->setText(0, QApplication::translate("settings", " TreeView", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem1 = ___qtreewidgetitem->child(1);
        ___qtreewidgetitem1->setText(0, QApplication::translate("settings", " TreeView", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem2 = ___qtreewidgetitem->child(2);
        ___qtreewidgetitem2->setText(0, QApplication::translate("settings", " TreeView", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem3 = ___qtreewidgetitem->child(3);
        ___qtreewidgetitem3->setText(0, QApplication::translate("settings", " TreeView", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem4 = ___qtreewidgetitem->child(4);
        ___qtreewidgetitem4->setText(0, QApplication::translate("settings", " TreeView", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem5 = ___qtreewidgetitem->child(5);
        ___qtreewidgetitem5->setText(0, QApplication::translate("settings", " TreeView", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem6 = ___qtreewidgetitem5->child(0);
        ___qtreewidgetitem6->setText(0, QApplication::translate("settings", " TreeView", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem7 = ___qtreewidgetitem6->child(0);
        ___qtreewidgetitem7->setText(0, QApplication::translate("settings", " TreeView", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem8 = ___qtreewidgetitem->child(6);
        ___qtreewidgetitem8->setText(0, QApplication::translate("settings", " TreeView", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem9 = ___qtreewidgetitem8->child(0);
        ___qtreewidgetitem9->setText(0, QApplication::translate("settings", " TreeView", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem10 = ___qtreewidgetitem8->child(1);
        ___qtreewidgetitem10->setText(0, QApplication::translate("settings", " TreeView", Q_NULLPTR));
        treeWidget_2->setSortingEnabled(__sortingEnabled);

        pushButton_8->setText(QString());
        pushButton_5->setText(QString());
        pushButton_6->setText(QString());
        pushButton_34->setText(QApplication::translate("settings", "On", Q_NULLPTR));
        pushButton_35->setText(QApplication::translate("settings", "Over", Q_NULLPTR));
        pushButton_36->setText(QApplication::translate("settings", "Normal", Q_NULLPTR));
        label_39->setText(QString());
        checkBox_31->setText(QApplication::translate("settings", "CheckBox1", Q_NULLPTR));
        checkBox_32->setText(QApplication::translate("settings", "CheckBox1", Q_NULLPTR));
        checkBox_33->setText(QApplication::translate("settings", "CheckBox1", Q_NULLPTR));
        checkBox_34->setText(QApplication::translate("settings", "CheckBox1", Q_NULLPTR));
        checkBox_35->setText(QApplication::translate("settings", "CheckBox1", Q_NULLPTR));
        label_40->setText(QString());
        label_43->setText(QString());
        radioButton_25->setText(QApplication::translate("settings", "Radio is off", Q_NULLPTR));
        radioButton_26->setText(QApplication::translate("settings", "Disabled on", Q_NULLPTR));
        radioButton_27->setText(QApplication::translate("settings", "Radio is on", Q_NULLPTR));
        radioButton_28->setText(QApplication::translate("settings", "Disabled", Q_NULLPTR));
        label_44->setText(QString());
        label_45->setText(QString());
        lineEdit_19->setText(QApplication::translate("settings", "Textbox", Q_NULLPTR));
        lineEdit_20->setText(QApplication::translate("settings", "Textbox", Q_NULLPTR));
        lineEdit_21->setText(QApplication::translate("settings", "Textbox", Q_NULLPTR));
        pushButton_37->setText(QApplication::translate("settings", "Disabled", Q_NULLPTR));
        checkBox_3->setText(QString());
        checkBox_4->setText(QString());
        comboBox->clear();
        comboBox->insertItems(0, QStringList()
         << QApplication::translate("settings", "ComboBox1", Q_NULLPTR)
         << QApplication::translate("settings", "ComboBox2", Q_NULLPTR)
         << QApplication::translate("settings", "ComboBox3", Q_NULLPTR)
        );

        const bool __sortingEnabled1 = treeWidget->isSortingEnabled();
        treeWidget->setSortingEnabled(false);
        QTreeWidgetItem *___qtreewidgetitem11 = treeWidget->topLevelItem(0);
        ___qtreewidgetitem11->setText(0, QApplication::translate("settings", " TreeView", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem12 = ___qtreewidgetitem11->child(0);
        ___qtreewidgetitem12->setText(0, QApplication::translate("settings", " TreeView", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem13 = ___qtreewidgetitem11->child(1);
        ___qtreewidgetitem13->setText(0, QApplication::translate("settings", " TreeView", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem14 = ___qtreewidgetitem11->child(2);
        ___qtreewidgetitem14->setText(0, QApplication::translate("settings", " TreeView", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem15 = ___qtreewidgetitem14->child(0);
        ___qtreewidgetitem15->setText(0, QApplication::translate("settings", " TreeView", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem16 = ___qtreewidgetitem15->child(0);
        ___qtreewidgetitem16->setText(0, QApplication::translate("settings", " TreeView", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem17 = ___qtreewidgetitem11->child(3);
        ___qtreewidgetitem17->setText(0, QApplication::translate("settings", " TreeView", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem18 = ___qtreewidgetitem17->child(0);
        ___qtreewidgetitem18->setText(0, QApplication::translate("settings", " TreeView", Q_NULLPTR));
        QTreeWidgetItem *___qtreewidgetitem19 = ___qtreewidgetitem17->child(1);
        ___qtreewidgetitem19->setText(0, QApplication::translate("settings", " TreeView", Q_NULLPTR));
        treeWidget->setSortingEnabled(__sortingEnabled1);

        pushButton_9->setText(QString());
        pushButton_7->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class settings: public Ui_settings {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SETTINGS_H
