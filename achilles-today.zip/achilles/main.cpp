#include "mainwindow.h"
#include <QApplication>

#include "splash.h"
#include "firewall.h"
#include "account.h"
#include "exploit.h"
#include "prevent.h"
#include "sand.h"
#include "settings.h"
#include "updatedialog.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    splash w;
    w.show();

    return a.exec();
}
