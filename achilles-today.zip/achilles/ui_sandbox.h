/********************************************************************************
** Form generated from reading UI file 'sandbox.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SANDBOX_H
#define UI_SANDBOX_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_sandbox
{
public:
    QWidget *widget;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QWidget *widget_2;
    QTableWidget *tableWidget_2;
    QLabel *label;
    QWidget *widget_3;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;

    void setupUi(QDialog *sandbox)
    {
        if (sandbox->objectName().isEmpty())
            sandbox->setObjectName(QStringLiteral("sandbox"));
        sandbox->resize(760, 576);
        widget = new QWidget(sandbox);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(0, 0, 760, 130));
        widget->setStyleSheet(QLatin1String("QWidget#widget{\n"
"background-image: url(:/images/settings/header.png);\n"
"}"));
        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(10, 98, 270, 32));
        pushButton->setStyleSheet(QLatin1String("\n"
"\n"
"QPushButton{border-image:url(:/images/settings/setting_button.png);border:0px; color:#ffffff;font: 12pt \"MS Shell Dlg 2\";} QPushButton:hover{border-image:url(:/images/settings/setting_button.png);border:0px; color:#ffffff;font: 12pt \"MS Shell Dlg 2\";} QPushButton:pressed{border-image:url(:/images/settings/setting_button.png); position: relative;top: 1px; left: 1px; color:#ffffff;font: 12pt \"MS Shell Dlg 2\";}"));
        pushButton->setFlat(true);
        pushButton_2 = new QPushButton(widget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(680, 0, 40, 40));
        pushButton_2->setStyleSheet(QStringLiteral("QPushButton{border-image:url(:/images/settings/minibutton_normal.png);border:0px;} QPushButton:hover{border-image:url(:/images/settings/minibutton_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/settings/minibutton_on.png); position: relative;top: 1px; left: 1px;}"));
        pushButton_3 = new QPushButton(widget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(720, 0, 40, 40));
        pushButton_3->setStyleSheet(QStringLiteral("QPushButton{border-image:url(:/images/settings/closebutton_normal.png);border:0px;} QPushButton:hover{border-image:url(:/images/settings/closebutton_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/settings/closebutton_on.png); position: relative;top: 1px; left: 1px;}"));
        pushButton_4 = new QPushButton(widget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(680, 40, 90, 90));
        pushButton_4->setStyleSheet(QStringLiteral("QPushButton{border-image:url(:/images/settings/back.png);border:0px;} QPushButton:hover{border-image:url(:/images/settings/back.png);border:0px} QPushButton:pressed{border-image:url(:/images/settings/back.png); position: relative;top: 1px; left: 1px;}"));
        widget_2 = new QWidget(sandbox);
        widget_2->setObjectName(QStringLiteral("widget_2"));
        widget_2->setGeometry(QRect(10, 130, 742, 432));
        widget_2->setStyleSheet(QLatin1String("QWidget#widget_2\n"
"{\n"
"background-image: url(:/images/update/background.png);\n"
"}\n"
""));
        tableWidget_2 = new QTableWidget(widget_2);
        if (tableWidget_2->columnCount() < 4)
            tableWidget_2->setColumnCount(4);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        if (tableWidget_2->rowCount() < 4)
            tableWidget_2->setRowCount(4);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        tableWidget_2->setVerticalHeaderItem(0, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        tableWidget_2->setVerticalHeaderItem(1, __qtablewidgetitem5);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        tableWidget_2->setVerticalHeaderItem(2, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        tableWidget_2->setVerticalHeaderItem(3, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        tableWidget_2->setItem(0, 0, __qtablewidgetitem8);
        QTableWidgetItem *__qtablewidgetitem9 = new QTableWidgetItem();
        tableWidget_2->setItem(0, 1, __qtablewidgetitem9);
        QTableWidgetItem *__qtablewidgetitem10 = new QTableWidgetItem();
        tableWidget_2->setItem(0, 2, __qtablewidgetitem10);
        QTableWidgetItem *__qtablewidgetitem11 = new QTableWidgetItem();
        tableWidget_2->setItem(0, 3, __qtablewidgetitem11);
        QTableWidgetItem *__qtablewidgetitem12 = new QTableWidgetItem();
        tableWidget_2->setItem(1, 0, __qtablewidgetitem12);
        QTableWidgetItem *__qtablewidgetitem13 = new QTableWidgetItem();
        tableWidget_2->setItem(1, 1, __qtablewidgetitem13);
        QTableWidgetItem *__qtablewidgetitem14 = new QTableWidgetItem();
        tableWidget_2->setItem(1, 2, __qtablewidgetitem14);
        QTableWidgetItem *__qtablewidgetitem15 = new QTableWidgetItem();
        tableWidget_2->setItem(1, 3, __qtablewidgetitem15);
        QTableWidgetItem *__qtablewidgetitem16 = new QTableWidgetItem();
        tableWidget_2->setItem(2, 0, __qtablewidgetitem16);
        QTableWidgetItem *__qtablewidgetitem17 = new QTableWidgetItem();
        tableWidget_2->setItem(2, 1, __qtablewidgetitem17);
        QTableWidgetItem *__qtablewidgetitem18 = new QTableWidgetItem();
        tableWidget_2->setItem(2, 2, __qtablewidgetitem18);
        QTableWidgetItem *__qtablewidgetitem19 = new QTableWidgetItem();
        tableWidget_2->setItem(2, 3, __qtablewidgetitem19);
        tableWidget_2->setObjectName(QStringLiteral("tableWidget_2"));
        tableWidget_2->setGeometry(QRect(0, 0, 741, 241));
        tableWidget_2->setStyleSheet(QLatin1String("QTableWidget#tableWidget\n"
"{\n"
"		border:none;\n"
"}"));
        label = new QLabel(widget_2);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(0, 260, 740, 32));
        label->setStyleSheet(QLatin1String("background-image: url(:/images/sandbox/profile.png);\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);"));
        widget_3 = new QWidget(widget_2);
        widget_3->setObjectName(QStringLiteral("widget_3"));
        widget_3->setGeometry(QRect(0, 300, 594, 130));
        label_2 = new QLabel(widget_3);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(0, 0, 592, 30));
        label_2->setStyleSheet(QLatin1String("font: 12pt \"MS Shell Dlg 2\";\n"
"color: rgb(69, 90, 100);"));
        label_3 = new QLabel(widget_3);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(1, 30, 592, 30));
        label_3->setStyleSheet(QLatin1String("font: 12pt \"MS Shell Dlg 2\";\n"
"background-image: url(:/images/sandbox/denyaccess.png);\n"
"color: rgb(69, 90, 100);"));
        label_4 = new QLabel(widget_3);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(0, 60, 592, 30));
        label_4->setStyleSheet(QLatin1String("font: 12pt \"MS Shell Dlg 2\";\n"
"color: rgb(69, 90, 100);"));
        label_5 = new QLabel(widget_3);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(0, 90, 592, 30));
        label_5->setStyleSheet(QLatin1String("font: 12pt \"MS Shell Dlg 2\";\n"
"color: rgb(69, 90, 100);"));
        pushButton_5 = new QPushButton(widget_2);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(600, 297, 138, 74));
        pushButton_5->setStyleSheet(QStringLiteral("QPushButton{border-image:url(:/images/sandbox/edit_normal.png);border:0px;} QPushButton:hover{border-image:url(:/images/sandbox/edit_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/sandbox/edit_on.png); position: relative;top: 1px; left: 1px;}"));
        pushButton_6 = new QPushButton(widget_2);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setGeometry(QRect(600, 363, 141, 74));
        pushButton_6->setStyleSheet(QStringLiteral("QPushButton{border-image:url(:/images/sandbox/add_normal.png);border:0px;} QPushButton:hover{border-image:url(:/images/sandbox/add_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/sandbox/add_on.png); position: relative;top: 1px; left: 1px;}"));

        retranslateUi(sandbox);

        QMetaObject::connectSlotsByName(sandbox);
    } // setupUi

    void retranslateUi(QDialog *sandbox)
    {
        sandbox->setWindowTitle(QApplication::translate("sandbox", "Dialog", Q_NULLPTR));
        pushButton->setText(QApplication::translate("sandbox", "Applications Run in Sandbox", Q_NULLPTR));
        pushButton_2->setText(QString());
        pushButton_3->setText(QString());
        pushButton_4->setText(QString());
        QTableWidgetItem *___qtablewidgetitem = tableWidget_2->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("sandbox", "Icon", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget_2->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("sandbox", "Name", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget_2->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("sandbox", "Path", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget_2->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("sandbox", "Details", Q_NULLPTR));

        const bool __sortingEnabled = tableWidget_2->isSortingEnabled();
        tableWidget_2->setSortingEnabled(false);
        QTableWidgetItem *___qtablewidgetitem4 = tableWidget_2->item(0, 0);
        ___qtablewidgetitem4->setText(QApplication::translate("sandbox", "Icon1", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem5 = tableWidget_2->item(0, 1);
        ___qtablewidgetitem5->setText(QApplication::translate("sandbox", "Game.exe", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem6 = tableWidget_2->item(0, 2);
        ___qtablewidgetitem6->setText(QApplication::translate("sandbox", "C:/Program Files/Game", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem7 = tableWidget_2->item(0, 3);
        ___qtablewidgetitem7->setText(QApplication::translate("sandbox", "Button1", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem8 = tableWidget_2->item(1, 0);
        ___qtablewidgetitem8->setText(QApplication::translate("sandbox", "Icon2", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem9 = tableWidget_2->item(1, 1);
        ___qtablewidgetitem9->setText(QApplication::translate("sandbox", "Updater.exe", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem10 = tableWidget_2->item(1, 2);
        ___qtablewidgetitem10->setText(QApplication::translate("sandbox", "C:/Program Files/Shared Data", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem11 = tableWidget_2->item(1, 3);
        ___qtablewidgetitem11->setText(QApplication::translate("sandbox", "Button2", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem12 = tableWidget_2->item(2, 0);
        ___qtablewidgetitem12->setText(QApplication::translate("sandbox", "Icon3", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem13 = tableWidget_2->item(2, 1);
        ___qtablewidgetitem13->setText(QApplication::translate("sandbox", "Updater.exe", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem14 = tableWidget_2->item(2, 2);
        ___qtablewidgetitem14->setText(QApplication::translate("sandbox", "C:/Program Files/Shared Data", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem15 = tableWidget_2->item(2, 3);
        ___qtablewidgetitem15->setText(QApplication::translate("sandbox", "Button2", Q_NULLPTR));
        tableWidget_2->setSortingEnabled(__sortingEnabled);

        label->setText(QApplication::translate("sandbox", "     Sandbox Profiles", Q_NULLPTR));
        label_2->setText(QApplication::translate("sandbox", "     Deny Internet Access", Q_NULLPTR));
        label_3->setText(QApplication::translate("sandbox", "     Deny Access To D:Private", Q_NULLPTR));
        label_4->setText(QApplication::translate("sandbox", "     Deny Write File Activity", Q_NULLPTR));
        label_5->setText(QApplication::translate("sandbox", "     Deny Registry Modification", Q_NULLPTR));
        pushButton_5->setText(QString());
        pushButton_6->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class sandbox: public Ui_sandbox {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SANDBOX_H
