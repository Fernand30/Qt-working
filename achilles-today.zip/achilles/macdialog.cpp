#include "macdialog.h"

#include <QHBoxLayout>
#include <QPushButton>
#include <QLabel>
#include <QGraphicsDropShadowEffect>
#include <QMouseEvent>

MacDialog::MacDialog(QWidget *parent):QDialog(parent)
{
    m_titleBar = NULL;
    setWindowFlags(Qt::Dialog | Qt::FramelessWindowHint);
}

void MacDialog::setupTitleBar(QWidget *titleWidget, QLabel *titleLabel, bool dialogStyle)
{
    QHBoxLayout *oldLayout = (QHBoxLayout *)titleWidget->layout();
    if (oldLayout != NULL)
    {
        oldLayout->removeWidget(titleLabel);
        delete oldLayout;
    }

    m_titleBar = titleWidget;

    QHBoxLayout *horizontalLayout = new QHBoxLayout(titleWidget);
    horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
    QWidget *leftMenuSpaceWidget = new QWidget(titleWidget);
    leftMenuSpaceWidget->setObjectName(QStringLiteral("leftMenuSpaceWidget"));
    QHBoxLayout *leftWindowButtonLayout = new QHBoxLayout(leftMenuSpaceWidget);
    leftWindowButtonLayout->setSpacing(12);
    leftWindowButtonLayout->setObjectName(QStringLiteral("leftWindowButtonLayout"));
    leftWindowButtonLayout->setContentsMargins(12, 0, 0, 3);
    QPushButton *leftCloseButton = new QPushButton(leftMenuSpaceWidget);
    leftCloseButton->setObjectName(QStringLiteral("leftCloseButton"));
    leftCloseButton->setMinimumSize(QSize(11, 11));
    leftCloseButton->setMaximumSize(QSize(11, 11));
    leftCloseButton->setStyleSheet(QStringLiteral("QPushButton{border-image:url(:/images/menu_close.png);border:0px;} QPushButton:hover{border-image:url(:/images/menu_close_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/menu_close_press.png); position: relative;top: 1px; left: 1px;}"));

    leftWindowButtonLayout->addWidget(leftCloseButton);

    QPushButton *leftMinimizeButton = new QPushButton(leftMenuSpaceWidget);
    leftMinimizeButton->setObjectName(QStringLiteral("leftMinimizeButton"));
    leftMinimizeButton->setMinimumSize(QSize(11, 11));
    leftMinimizeButton->setMaximumSize(QSize(11, 11));
    leftMinimizeButton->setStyleSheet(QStringLiteral("QPushButton{border-image:url(:/images/menu_minimize.png);border:0px;} QPushButton:hover{border-image:url(:/images/menu_minimize_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/menu_minimize_press.png); position: relative;top: 1px; left: 1px;}"));

    leftWindowButtonLayout->addWidget(leftMinimizeButton);

    QPushButton *leftMaximizeButton = new QPushButton(leftMenuSpaceWidget);
    leftMaximizeButton->setObjectName(QStringLiteral("leftMaximizeButton"));
    leftMaximizeButton->setMinimumSize(QSize(11, 11));
    leftMaximizeButton->setMaximumSize(QSize(11, 11));
    leftMaximizeButton->setStyleSheet(QStringLiteral("QPushButton{border-image:url(:/images/menu_maximize.png);border:0px;} QPushButton:hover{border-image:url(:/images/menu_maximize_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/menu_maximize_press.png); position: relative;top: 1px; left: 1px;} QPushButton:disabled{border-image:url(:/images/menu_maximize_press.png);}"));
    if (dialogStyle)
        leftMaximizeButton->setEnabled(false);

    leftWindowButtonLayout->addWidget(leftMaximizeButton);

    QWidget *leftWindowButtonSpace = new QWidget(leftMenuSpaceWidget);
    leftWindowButtonSpace->setObjectName(QStringLiteral("leftWindowButtonSpace"));

    leftWindowButtonLayout->addWidget(leftWindowButtonSpace);


    horizontalLayout->addWidget(leftMenuSpaceWidget);

    horizontalLayout->addWidget(titleLabel);

    QWidget *rightMenuSpaceWidget = new QWidget(titleWidget);
    rightMenuSpaceWidget->setObjectName(QStringLiteral("rightMenuSpaceWidget"));
    QHBoxLayout *rightWindowButtonLayout = new QHBoxLayout(rightMenuSpaceWidget);
    rightWindowButtonLayout->setSpacing(12);
    rightWindowButtonLayout->setObjectName(QStringLiteral("rightWindowButtonLayout"));
    rightWindowButtonLayout->setContentsMargins(0, 0, 12, 3);
    QWidget *rightWindowButtonSpace = new QWidget(rightMenuSpaceWidget);
    rightWindowButtonSpace->setObjectName(QStringLiteral("rightWindowButtonSpace"));

    rightWindowButtonLayout->addWidget(rightWindowButtonSpace);

    QPushButton *rightMaximizeButton = new QPushButton(rightMenuSpaceWidget);
    rightMaximizeButton->setObjectName(QStringLiteral("rightMaximizeButton"));
    rightMaximizeButton->setMinimumSize(QSize(11, 11));
    rightMaximizeButton->setMaximumSize(QSize(11, 11));
    rightMaximizeButton->setStyleSheet(QStringLiteral("QPushButton{border-image:url(:/images/menu_maximize.png);border:0px;} QPushButton:hover{border-image:url(:/images/menu_maximize_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/menu_maximize_press.png); position: relative;top: 1px; left: 1px;} QPushButton:disabled{border-image:url(:/images/menu_maximize_press.png);}"));
    if (dialogStyle)
        rightMaximizeButton->setEnabled(false);

    rightWindowButtonLayout->addWidget(rightMaximizeButton);

    QPushButton *rightMinimizeButton = new QPushButton(rightMenuSpaceWidget);
    rightMinimizeButton->setObjectName(QStringLiteral("rightMinimizeButton"));
    rightMinimizeButton->setMinimumSize(QSize(11, 11));
    rightMinimizeButton->setMaximumSize(QSize(11, 11));
    rightMinimizeButton->setStyleSheet(QStringLiteral("QPushButton{border-image:url(:/images/menu_minimize.png);border:0px;} QPushButton:hover{border-image:url(:/images/menu_minimize_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/menu_minimize_press.png); position: relative;top: 1px; left: 1px;}"));

    rightWindowButtonLayout->addWidget(rightMinimizeButton);

    QPushButton *rightCloseButton = new QPushButton(rightMenuSpaceWidget);
    rightCloseButton->setObjectName(QStringLiteral("rightCloseButton"));
    rightCloseButton->setMinimumSize(QSize(11, 11));
    rightCloseButton->setMaximumSize(QSize(11, 11));
    rightCloseButton->setStyleSheet(QStringLiteral("QPushButton{border-image:url(:/images/menu_close.png);border:0px;} QPushButton:hover{border-image:url(:/images/menu_close_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/menu_close_press.png); position: relative;top: 1px; left: 1px;}"));

    rightWindowButtonLayout->addWidget(rightCloseButton);


    horizontalLayout->addWidget(rightMenuSpaceWidget);

    connect(leftCloseButton, SIGNAL(clicked()), this, SLOT(close()));
    connect(leftMinimizeButton, SIGNAL(clicked()), this, SLOT(showMinimized()));
    connect(leftMaximizeButton, SIGNAL(clicked()), this, SLOT(showMaximized()));

    connect(rightCloseButton, SIGNAL(clicked()), this, SLOT(close()));
    connect(rightMinimizeButton, SIGNAL(clicked()), this, SLOT(showMinimized()));
    connect(rightMaximizeButton, SIGNAL(clicked()), this, SLOT(showMaximized()));
}

void MacDialog::addShadowEffect()
{
    setAttribute(Qt::WA_TranslucentBackground);
    window()->layout()->setMargin(20);
    QGraphicsDropShadowEffect* effect = new QGraphicsDropShadowEffect();
    effect->setBlurRadius(20);
    setGraphicsEffect(effect);
}

void MacDialog::mouseMoveEvent(QMouseEvent *event)
{
    if (m_titleBar == NULL)
        return;

    if (event->buttons() && Qt::LeftButton) {
        if (m_capturedMenuBar)
        {
            move(event->globalPos() - m_dragPosition);
        }
        else
        {
            QRect titleRect = m_titleBar->frameGeometry();
            QPoint touchPos = event->globalPos() - frameGeometry().topLeft();
            if (titleRect.contains(touchPos))
            {
                m_capturedMenuBar = true;
                m_dragPosition = touchPos;
            }
        }
        event->accept();
    }
}

void MacDialog::mousePressEvent(QMouseEvent *event)
{
    if (m_titleBar == NULL)
        return;

    m_capturedMenuBar = false;
    if (event->button() == Qt::LeftButton) {
        QRect titleRect = m_titleBar->frameGeometry();
        QPoint touchPos = event->globalPos() - frameGeometry().topLeft();
        if (titleRect.contains(touchPos))
        {
            m_capturedMenuBar = true;
            m_dragPosition = touchPos;
            event->accept();
        }
    }
}

void MacDialog::mouseReleaseEvent(QMouseEvent *event)
{
    if (m_titleBar == NULL)
        return;

    m_capturedMenuBar = false;
}
