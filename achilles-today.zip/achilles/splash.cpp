#include "splash.h"
#include "ui_splash.h"

#include <QMouseEvent>
#include <QApplication>
#include <QGraphicsDropShadowEffect>
#include "qdebug.h"


#include "qtimer.h"
#include "mainmenu.h"

splash::splash(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::splash)
{
    completeUi();
}

splash::~splash()
{
    delete ui;
}
void splash::completeUi()
{
    ui->setupUi(this);
    setWindowFlags(Qt::Window | Qt::FramelessWindowHint);
    QTimer::singleShot(1000, this, SLOT(updateCaption()));
}

void splash::updateCaption()
{
    this->close();
    mainmenu *ui = new mainmenu();
    ui->exec();
}
