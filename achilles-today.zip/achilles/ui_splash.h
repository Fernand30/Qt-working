/********************************************************************************
** Form generated from reading UI file 'splash.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SPLASH_H
#define UI_SPLASH_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_splash
{
public:
    QPushButton *pushButton;

    void setupUi(QDialog *splash)
    {
        if (splash->objectName().isEmpty())
            splash->setObjectName(QStringLiteral("splash"));
        splash->resize(760, 580);
        splash->setStyleSheet(QLatin1String("\n"
"QDialog#splash{\n"
"background-image: url(:/images/splash.png);\n"
"}"));
        pushButton = new QPushButton(splash);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(630, 540, 121, 31));
        pushButton->setStyleSheet(QLatin1String("color: rgb(233, 174, 134);\n"
"font: 11pt \"MS Shell Dlg 2\";"));
        pushButton->setFlat(true);

        retranslateUi(splash);

        QMetaObject::connectSlotsByName(splash);
    } // setupUi

    void retranslateUi(QDialog *splash)
    {
        splash->setWindowTitle(QApplication::translate("splash", "Dialog", Q_NULLPTR));
        pushButton->setText(QApplication::translate("splash", "VERSION 1.0.1", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class splash: public Ui_splash {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SPLASH_H
