#include "mainmenu.h"
#include "ui_mainmenu.h"

#include <QMouseEvent>
#include <QApplication>
#include <QGraphicsDropShadowEffect>
#include "qdebug.h"

mainmenu::mainmenu(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::mainmenu)
{
    completeUi();
    connect(ui->pushButton_4, SIGNAL(clicked()), this, SLOT(prevente()));
    connect(ui->pushButton_5, SIGNAL(clicked()), this, SLOT(fire()));
    connect(ui->pushButton_6, SIGNAL(clicked()), this, SLOT(exp()));
    connect(ui->pushButton_8, SIGNAL(clicked()), this, SLOT(updateDlg()));
    connect(ui->pushButton_9, SIGNAL(clicked()), this, SLOT(sett()));
    connect(ui->pushButton_10, SIGNAL(clicked()), this, SLOT(acc()));
}

mainmenu::~mainmenu()
{
    delete ui;
}

void mainmenu::completeUi()
{
    ui->setupUi(this);
    setWindowFlags(Qt::Window | Qt::FramelessWindowHint);

    //connect(ui->pushButton_3, SIGNAL(clicked()), qApp, SLOT(quit()));
    connect(ui->pushButton_2, SIGNAL(clicked()), this, SLOT(showMinimized()));
//    connect(ui->rightMinimizeButton, SIGNAL(clicked()), this, SLOT(showMinimized()));
//    connect(ui->leftMaximizeButton, SIGNAL(clicked()), this, SLOT(clickedMaximizeButton()));
//    connect(ui->rightMaximizeButton, SIGNAL(clicked()), this, SLOT(clickedMaximizeButton()));
}
void mainmenu::prevente()
{
    prevent  * ui = new prevent();
    ui->exec();
}

void mainmenu::fire()
{
    Firewall  * ui = new Firewall();
    ui->exec();
}
void mainmenu::exp()
{
    exploit  * ui = new exploit();
    ui->exec();
}
void mainmenu::sandbox()
{
    qDebug()<<"sand";
    sand  * ui = new sand();
    ui->exec();
}
void mainmenu::updateDlg()
{
    updateDialog *ui  = new updateDialog();
    ui->exec();
}
void mainmenu::sett()
{
    settings  * ui = new settings();
    ui->exec();
}
void mainmenu::acc()
{
    Account  * ui = new Account();
    ui->exec();
}

void mainmenu::on_pushButton_7_clicked()
{
    sand  * ui = new sand();
    ui->exec();
}

void mainmenu::on_pushButton_3_clicked()
{
    close();
}


void mainmenu::mouseMoveEvent(QMouseEvent *event)
{
    if (event->buttons() && Qt::LeftButton) {
        if (m_capturedMenuBar)
        {
            move(event->globalPos() - m_dragPosition);
        }
        else
        {
            QRect titleRect = ui->widget_2->frameGeometry();
            QPoint touchPos = event->globalPos() - frameGeometry().topLeft();
            if (titleRect.contains(touchPos))
            {
                m_capturedMenuBar = true;
                m_dragPosition = touchPos;
            }
        }
        event->accept();
    }
}

void mainmenu::mousePressEvent(QMouseEvent *event)
{
    m_capturedMenuBar = false;
    if (event->button() == Qt::LeftButton) {
        QRect titleRect = ui->widget_2->frameGeometry();
        QPoint touchPos = event->globalPos() - frameGeometry().topLeft();
        if (titleRect.contains(touchPos))
        {
            m_capturedMenuBar = true;
            m_dragPosition = touchPos;
            event->accept();
        }
    }
}

void mainmenu::mouseReleaseEvent(QMouseEvent *event)
{
    m_capturedMenuBar = false;
}
