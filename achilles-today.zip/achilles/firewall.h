#ifndef FIREWALL_H
#define FIREWALL_H

#include <QDialog>

namespace Ui {
class Firewall;
}

class Firewall : public QDialog
{
    Q_OBJECT

public:
    explicit Firewall(QWidget *parent = 0);
    ~Firewall();

protected:
    void    mouseMoveEvent(QMouseEvent *event);
    void    mousePressEvent(QMouseEvent *event);
    void    mouseReleaseEvent(QMouseEvent *event);
private:
    QPoint          m_dragPosition;
    bool            m_capturedMenuBar;

private slots:
    void on_pushButton_clicked();

private:
    Ui::Firewall *ui;
    void autoWidth();
    void completeUi();
};

#endif // FIREWALL_H
