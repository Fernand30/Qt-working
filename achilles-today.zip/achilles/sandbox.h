#ifndef SANDBOX_H
#define SANDBOX_H

#include <QDialog>

namespace Ui {
class sandbox;
}

class sandbox : public QDialog
{
    Q_OBJECT

public:
    explicit sandbox(QWidget *parent = 0);
    ~sandbox();

private:
    Ui::sandbox *ui;
    void autoWidth();
    void completeUi();
};

#endif // SANDBOX_H
