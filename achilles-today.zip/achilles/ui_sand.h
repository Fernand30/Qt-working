/********************************************************************************
** Form generated from reading UI file 'sand.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SAND_H
#define UI_SAND_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_sand
{
public:
    QWidget *widget;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QTableWidget *tableWidget_2;
    QLabel *label;
    QLabel *label_6;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QListWidget *listWidget;

    void setupUi(QDialog *sand)
    {
        if (sand->objectName().isEmpty())
            sand->setObjectName(QStringLiteral("sand"));
        sand->resize(760, 576);
        sand->setStyleSheet(QLatin1String("QDialog#sand{\n"
"		background-color: rgb(255, 255, 255);\n"
"}"));
        widget = new QWidget(sand);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(0, 0, 760, 130));
        widget->setStyleSheet(QLatin1String("QWidget#widget{\n"
"background-image: url(:/images/settings/header.png);\n"
"}"));
        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(10, 98, 270, 32));
        QFont font;
        font.setFamily(QStringLiteral("MS Shell Dlg 2"));
        font.setPointSize(14);
        font.setBold(false);
        font.setItalic(false);
        font.setWeight(50);
        pushButton->setFont(font);
        pushButton->setStyleSheet(QLatin1String("QPushButton{\n"
"		border-image:url(:/images/sandbox/sandboxbutton.png);\n"
"		border:0px; color:#ffffff;\n"
"		font: 14pt \"MS Shell Dlg 2\";\n"
"		border-top-left-radius: 3px;\n"
"		border-top-right-radius: 3px\n"
"} \n"
"/*QPushButton:hover{\n"
"		border-image:url(:/images/sandbox/sandboxbutton.png);border:0px; color:#ffffff;font: 12pt \"MS Shell Dlg 2\";\n"
"		border-top-left-radius: 3px;\n"
"		border-top-right-radius: 3px\n"
"} \n"
"QPushButton:pressed{\n"
"		border-image:url(:/images/sandbox/sandboxbutton.png); position: relative;top: 1px; left: 1px; color:#ffffff;font: 12pt \"MS Shell Dlg 2\";\n"
"		border-top-left-radius: 3px;\n"
"		border-top-right-radius: 3px\n"
"}*/"));
        pushButton->setFlat(true);
        pushButton_2 = new QPushButton(widget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(680, 0, 40, 40));
        pushButton_2->setStyleSheet(QStringLiteral("QPushButton{border-image:url(:/images/settings/minibutton_normal.png);border:0px;} QPushButton:hover{border-image:url(:/images/settings/minibutton_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/settings/minibutton_on.png); position: relative;top: 1px; left: 1px;}"));
        pushButton_3 = new QPushButton(widget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(720, 0, 40, 40));
        pushButton_3->setStyleSheet(QStringLiteral("QPushButton{border-image:url(:/images/settings/closebutton_normal.png);border:0px;} QPushButton:hover{border-image:url(:/images/settings/closebutton_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/settings/closebutton_on.png); position: relative;top: 1px; left: 1px;}"));
        pushButton_4 = new QPushButton(widget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(670, 40, 90, 90));
        pushButton_4->setStyleSheet(QLatin1String("QPushButton{\n"
"		border-image:url(:/images/back_normal.png);border:0px;\n"
"} \n"
"QPushButton:hover{\n"
"		border-image:url(:/images/back_over.png);border:0px;\n"
"} \n"
"QPushButton:pressed{\n"
"		border-image:url(:/images/back_on.png); position: relative;top: 1px; left: 1px;\n"
"}"));
        tableWidget_2 = new QTableWidget(sand);
        if (tableWidget_2->columnCount() < 4)
            tableWidget_2->setColumnCount(4);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidget_2->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        if (tableWidget_2->rowCount() < 4)
            tableWidget_2->setRowCount(4);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        tableWidget_2->setVerticalHeaderItem(0, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        tableWidget_2->setVerticalHeaderItem(1, __qtablewidgetitem5);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        tableWidget_2->setVerticalHeaderItem(2, __qtablewidgetitem6);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        tableWidget_2->setVerticalHeaderItem(3, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        tableWidget_2->setItem(0, 0, __qtablewidgetitem8);
        QTableWidgetItem *__qtablewidgetitem9 = new QTableWidgetItem();
        tableWidget_2->setItem(0, 1, __qtablewidgetitem9);
        QTableWidgetItem *__qtablewidgetitem10 = new QTableWidgetItem();
        tableWidget_2->setItem(0, 2, __qtablewidgetitem10);
        QTableWidgetItem *__qtablewidgetitem11 = new QTableWidgetItem();
        tableWidget_2->setItem(0, 3, __qtablewidgetitem11);
        QTableWidgetItem *__qtablewidgetitem12 = new QTableWidgetItem();
        tableWidget_2->setItem(1, 0, __qtablewidgetitem12);
        QTableWidgetItem *__qtablewidgetitem13 = new QTableWidgetItem();
        tableWidget_2->setItem(1, 1, __qtablewidgetitem13);
        QTableWidgetItem *__qtablewidgetitem14 = new QTableWidgetItem();
        tableWidget_2->setItem(1, 2, __qtablewidgetitem14);
        QTableWidgetItem *__qtablewidgetitem15 = new QTableWidgetItem();
        tableWidget_2->setItem(1, 3, __qtablewidgetitem15);
        QTableWidgetItem *__qtablewidgetitem16 = new QTableWidgetItem();
        tableWidget_2->setItem(2, 0, __qtablewidgetitem16);
        QTableWidgetItem *__qtablewidgetitem17 = new QTableWidgetItem();
        tableWidget_2->setItem(2, 1, __qtablewidgetitem17);
        QTableWidgetItem *__qtablewidgetitem18 = new QTableWidgetItem();
        tableWidget_2->setItem(2, 2, __qtablewidgetitem18);
        QTableWidgetItem *__qtablewidgetitem19 = new QTableWidgetItem();
        tableWidget_2->setItem(2, 3, __qtablewidgetitem19);
        tableWidget_2->setObjectName(QStringLiteral("tableWidget_2"));
        tableWidget_2->setGeometry(QRect(10, 140, 740, 234));
        tableWidget_2->setStyleSheet(QLatin1String("QHeaderView::section {\n"
"    background-color: #ffffff;\n"
"    font-size: 14pt;\n"
"	color:#8399a4;\n"
"	border:1px solid #fffff8; \n"
"}\n"
"\n"
"QHeaderView::section:horizontal\n"
"{\n"
"    border-color: #cfd8dc;\n"
"}\n"
"QHeaderView::section:vertical\n"
"{\n"
"   \n"
"}\n"
"QTableWidget{\n"
"	border:1px solid #cfd8dc;\n"
"	color:#84a0b4;\n"
"    font-size:11pt;\n"
"}\n"
"\n"
"/*QTableWidget{\n"
"	border:1px solid #8399a4;\n"
"	color:#84a0b4;\n"
"    font-size:11pt;\n"
"}\n"
"QHeaderView {\n"
"     color:#8399a4;\n"
" font-size: 14pt;\n"
"}\n"
"\n"
"QHeaderView::section:horizontal\n"
"{\n"
"     background-color: #ffffff;\n"
"    font-size: 12pt;\n"
"	color:#8399a4;\n"
"	border:1px solid #fffff8; \n"
"}*/\n"
"\n"
" QTableWidget{\n"
"         /*selection-background-color: qlineargradient(x1: 0, y1: 0, x2: 0.5, y2: 0.5,\n"
"                                     stop: 0 #FF92BB, stop: 1 white);*/\n"
"			selection-background-color:#bbdefb;\n"
"			selection-color:#84a0b4;\n"
"     }"));
        tableWidget_2->setAutoScroll(false);
        tableWidget_2->setAlternatingRowColors(true);
        tableWidget_2->setSelectionMode(QAbstractItemView::SingleSelection);
        tableWidget_2->setSelectionBehavior(QAbstractItemView::SelectRows);
        label = new QLabel(sand);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(10, 670, 740, 32));
        label->setStyleSheet(QLatin1String("background-image: url(:/images/sandbox/profile.png);\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);"));
        label_6 = new QLabel(sand);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(10, 396, 740, 32));
        label_6->setStyleSheet(QLatin1String("background-image: url(:/images/sandbox/profile.png);\n"
"font: 14pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 255, 255);"));
        pushButton_5 = new QPushButton(sand);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(607, 434, 156, 75));
        pushButton_5->setStyleSheet(QStringLiteral("QPushButton{border-image:url(:/images/sandbox/edit_normal.png);border:0px;} QPushButton:hover{border-image:url(:/images/sandbox/edit_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/sandbox/edit_on.png); position: relative;top: 1px; left: 1px;}"));
        pushButton_6 = new QPushButton(sand);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setGeometry(QRect(607, 501, 156, 75));
        pushButton_6->setStyleSheet(QStringLiteral("QPushButton{border-image:url(:/images/sandbox/add_normal.png);border:0px;} QPushButton:hover{border-image:url(:/images/sandbox/add_over.png);border:0px} QPushButton:pressed{border-image:url(:/images/sandbox/add_on.png); position: relative;top: 1px; left: 1px;}"));
        listWidget = new QListWidget(sand);
        new QListWidgetItem(listWidget);
        new QListWidgetItem(listWidget);
        new QListWidgetItem(listWidget);
        new QListWidgetItem(listWidget);
        listWidget->setObjectName(QStringLiteral("listWidget"));
        listWidget->setGeometry(QRect(10, 440, 591, 126));
        QFont font1;
        font1.setPointSize(12);
        listWidget->setFont(font1);
        listWidget->setAutoFillBackground(false);
        listWidget->setStyleSheet(QLatin1String("QListView{\n"
"	border:1px solid #cfd8dc; \n"
"	color: rgb(69, 90, 100);\n"
"}\n"
"\n"
"QListView::item:selected{\n"
"	 color: #ffffff; \n"
"	background-color:#ff9e80;\n"
"	\n"
"}\n"
"	"));
        listWidget->setFrameShadow(QFrame::Sunken);
        listWidget->setLineWidth(1);
        listWidget->setMidLineWidth(1);
        listWidget->setSizeAdjustPolicy(QAbstractScrollArea::AdjustIgnored);
        listWidget->setAutoScroll(true);
        listWidget->setTabKeyNavigation(false);
        listWidget->setProperty("showDropIndicator", QVariant(true));
        listWidget->setDragEnabled(false);
        listWidget->setDragDropOverwriteMode(false);
        listWidget->setAlternatingRowColors(true);
        listWidget->setSelectionBehavior(QAbstractItemView::SelectRows);

        retranslateUi(sand);

        QMetaObject::connectSlotsByName(sand);
    } // setupUi

    void retranslateUi(QDialog *sand)
    {
        sand->setWindowTitle(QApplication::translate("sand", "Dialog", Q_NULLPTR));
        pushButton->setText(QApplication::translate("sand", "Applications Run in Sandbox", Q_NULLPTR));
        pushButton_2->setText(QString());
        pushButton_3->setText(QString());
        pushButton_4->setText(QString());
        QTableWidgetItem *___qtablewidgetitem = tableWidget_2->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("sand", "Icon", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget_2->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("sand", "Name", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget_2->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("sand", "Path", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget_2->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("sand", "Details", Q_NULLPTR));

        const bool __sortingEnabled = tableWidget_2->isSortingEnabled();
        tableWidget_2->setSortingEnabled(false);
        QTableWidgetItem *___qtablewidgetitem4 = tableWidget_2->item(0, 0);
        ___qtablewidgetitem4->setText(QApplication::translate("sand", "Icon1", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem5 = tableWidget_2->item(0, 1);
        ___qtablewidgetitem5->setText(QApplication::translate("sand", "Game.exe", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem6 = tableWidget_2->item(0, 2);
        ___qtablewidgetitem6->setText(QApplication::translate("sand", "C:/Program Files/Game", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem7 = tableWidget_2->item(0, 3);
        ___qtablewidgetitem7->setText(QApplication::translate("sand", "Button1", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem8 = tableWidget_2->item(1, 0);
        ___qtablewidgetitem8->setText(QApplication::translate("sand", "Icon2", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem9 = tableWidget_2->item(1, 1);
        ___qtablewidgetitem9->setText(QApplication::translate("sand", "Updater.exe", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem10 = tableWidget_2->item(1, 2);
        ___qtablewidgetitem10->setText(QApplication::translate("sand", "C:/Program Files/Shared Data", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem11 = tableWidget_2->item(1, 3);
        ___qtablewidgetitem11->setText(QApplication::translate("sand", "Button2", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem12 = tableWidget_2->item(2, 0);
        ___qtablewidgetitem12->setText(QApplication::translate("sand", "Icon3", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem13 = tableWidget_2->item(2, 1);
        ___qtablewidgetitem13->setText(QApplication::translate("sand", "Updater.exe", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem14 = tableWidget_2->item(2, 2);
        ___qtablewidgetitem14->setText(QApplication::translate("sand", "C:/Program Files/Shared Data", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem15 = tableWidget_2->item(2, 3);
        ___qtablewidgetitem15->setText(QApplication::translate("sand", "Button2", Q_NULLPTR));
        tableWidget_2->setSortingEnabled(__sortingEnabled);

        label->setText(QApplication::translate("sand", "     Sandbox Profiles", Q_NULLPTR));
        label_6->setText(QApplication::translate("sand", "     Sandbox Profiles", Q_NULLPTR));
        pushButton_5->setText(QString());
        pushButton_6->setText(QString());

        const bool __sortingEnabled1 = listWidget->isSortingEnabled();
        listWidget->setSortingEnabled(false);
        QListWidgetItem *___qlistwidgetitem = listWidget->item(0);
        ___qlistwidgetitem->setText(QApplication::translate("sand", "Deny Internet Access", Q_NULLPTR));
        QListWidgetItem *___qlistwidgetitem1 = listWidget->item(1);
        ___qlistwidgetitem1->setText(QApplication::translate("sand", "Deny Access To D:Private", Q_NULLPTR));
        QListWidgetItem *___qlistwidgetitem2 = listWidget->item(2);
        ___qlistwidgetitem2->setText(QApplication::translate("sand", "Deny Write File Activity", Q_NULLPTR));
        QListWidgetItem *___qlistwidgetitem3 = listWidget->item(3);
        ___qlistwidgetitem3->setText(QApplication::translate("sand", "Deny Registry Modification", Q_NULLPTR));
        listWidget->setSortingEnabled(__sortingEnabled1);

    } // retranslateUi

};

namespace Ui {
    class sand: public Ui_sand {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SAND_H
