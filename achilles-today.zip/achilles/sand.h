#ifndef SAND_H
#define SAND_H

#include <QDialog>

namespace Ui {
class sand;
}

class sand : public QDialog
{
    Q_OBJECT

public:
    explicit sand(QWidget *parent = 0);
    ~sand();

protected:
    void    mouseMoveEvent(QMouseEvent *event);
    void    mousePressEvent(QMouseEvent *event);
    void    mouseReleaseEvent(QMouseEvent *event);
private:
    QPoint          m_dragPosition;
    bool            m_capturedMenuBar;


private slots:
    void on_pushButton_3_clicked();

private:
    Ui::sand *ui;
    void autoWidth();
    void completeUi();
};

#endif // SAND_H
