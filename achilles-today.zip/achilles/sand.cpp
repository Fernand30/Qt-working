#include "sand.h"
#include "ui_sand.h"

#include <QMouseEvent>
#include <QApplication>
#include <QGraphicsDropShadowEffect>
#include "qdebug.h"

sand::sand(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::sand)
{
    completeUi();
    autoWidth();
}

sand::~sand()
{
    delete ui;
}
void sand::completeUi()
{
    ui->setupUi(this);
    setWindowFlags(Qt::Window | Qt::FramelessWindowHint);
    connect(ui->pushButton_2, SIGNAL(clicked()), this, SLOT(showMinimized()));
    //connect(ui->pushButton_3, SIGNAL(clicked()), qApp, SLOT(quit()));
}
void sand::autoWidth()
{
        ui->tableWidget_2->verticalHeader()->hide();
        ui->tableWidget_2->setColumnWidth(0,100);
        ui->tableWidget_2->setColumnWidth(1,150);
        ui->tableWidget_2->setColumnWidth(2,309);
        ui->tableWidget_2->setColumnWidth(3,180);
        ui->tableWidget_2->horizontalHeader()->setStretchLastSection(true);
        ui->tableWidget_2->setSelectionMode(QAbstractItemView::SingleSelection);
        ui->tableWidget_2->selectRow(0);
}

void sand::on_pushButton_3_clicked()
{
    close();
}
void sand::mouseMoveEvent(QMouseEvent *event)
{
    if (event->buttons() && Qt::LeftButton) {
        if (m_capturedMenuBar)
        {
            move(event->globalPos() - m_dragPosition);
        }
        else
        {
            QRect titleRect = ui->widget->frameGeometry();
            QPoint touchPos = event->globalPos() - frameGeometry().topLeft();
            if (titleRect.contains(touchPos))
            {
                m_capturedMenuBar = true;
                m_dragPosition = touchPos;
            }
        }
        event->accept();
    }
}

void sand::mousePressEvent(QMouseEvent *event)
{
    m_capturedMenuBar = false;
    if (event->button() == Qt::LeftButton) {
        QRect titleRect = ui->widget->frameGeometry();
        QPoint touchPos = event->globalPos() - frameGeometry().topLeft();
        if (titleRect.contains(touchPos))
        {
            m_capturedMenuBar = true;
            m_dragPosition = touchPos;
            event->accept();
        }
    }
}

void sand::mouseReleaseEvent(QMouseEvent *event)
{
    m_capturedMenuBar = false;
}
